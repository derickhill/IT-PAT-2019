package hill;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Questionnaire 
{

    private final boolean q1;
    private final boolean q2;
    private final boolean q3;
    private final boolean q4;
    private final boolean q5;
    private final boolean q6;
    private final boolean q7;
    private final boolean q8;
    private final boolean q9;
    private final boolean q10;
    private final boolean q11;
    private final boolean q12;
    private final boolean q13;
    private final boolean q14;
    private final boolean q15;
    private final boolean q16;
    private final boolean q17;
    private final boolean q18;
    private final boolean q19;
    private final boolean q20;
    private final boolean q21;
    private final boolean q22;
    private final boolean q23;
    private final boolean q24;
    private final boolean q25;
    private final boolean q26;
    private final boolean q27;
    private final boolean q28;
    private final boolean q29;
    private final boolean q30;
    private final boolean q31;
    private final boolean q32;
    private final boolean q33;
    private final boolean q34;
    private final boolean q35;
    private final boolean q36;
    private final boolean q37;
    private final boolean q38;
    private final boolean q39;
    private final boolean q40;
    private final boolean q41;
    private final boolean q42;
    private final boolean q43;
    private final boolean q44;
    private final boolean q45;
    private final boolean q46;
    private final boolean q47;
    private final boolean q48;
    private final boolean q49;
    private final boolean q50;
    private final boolean q51;
    private final boolean q52;
    private final boolean q53;
    private final boolean q54;
    private final boolean q55;
    private final boolean q56;
    private final boolean q57;
    
    private Connection connection = null;
    private Statement statement = null;
    private PreparedStatement toTblQuestionnaire = null;
    private ResultSet qnaireID = null;    
    
    private final String msAccDB = "dbWCBS.accdb";
    private final String dbURL = "jdbc:ucanaccess://" + msAccDB; 
    
    Questionnaire(boolean a, boolean b, boolean c, boolean d, boolean e, boolean f, boolean g, boolean h, boolean i, boolean j,
            boolean k, boolean l, boolean m, boolean n, boolean o, boolean p, boolean q, boolean r, boolean s, boolean t, boolean u,
            boolean v, boolean w, boolean x, boolean y, boolean z, boolean aa, boolean ab, boolean ac, boolean ad, boolean ae, boolean af,
            boolean ag, boolean ah, boolean ai, boolean aj, boolean ak, boolean al, boolean am, boolean an, boolean ao, boolean ap, boolean aq,
            boolean ar, boolean as, boolean at, boolean au, boolean av, boolean aw, boolean ax, boolean ay, boolean az, boolean ba, boolean bb,
            boolean bc, boolean bd, boolean be)//Instantiates a Questionnaire object with the 57 accepted boolean values as the answers to the questionnaire in the application.
    {
        q1 = a;
        q2 = b;
        q3 = c;
        q4 = d;
        q5 = e;
        q6 = f;
        q7 = g;
        q8 = h;
        q9 = i;
        q10 = j;
        q11 = k;
        q12 = l;
        q13 = m;
        q14 = n;
        q15 = o;
        q16 = p;
        q17 = q;
        q18 = r;
        q19 = s;
        q20 = t;
        q21 = u;
        q22 = v;
        q23 = w;
        q24 = x;
        q25 = y;
        q26 = z;
        q27 = aa;
        q28 = ab;
        q29 = ac;
        q30 = ad;
        q31 = ae;
        q32 = af;
        q33 = ag;
        q34 = ah;
        q35 = ai;
        q36 = aj;
        q37 = ak;
        q38 = al;
        q39 = am;
        q40 = an;
        q41 = ao;
        q42 = ap;
        q43 = aq;
        q44 = ar;
        q45 = as;
        q46 = at;
        q47 = au;
        q48 = av;
        q49 = aw;
        q50 = ax;
        q51 = ay;
        q52 = az;
        q53 = ba;
        q54 = bb;
        q55 = bc;
        q56 = bd;
        q57 = be;
        
    }
    
    public void toTable(String user)//Inserts the values in a new record in tblQuestionnaire where the DonorID field is equal to the DonorID field where the username field is equal to the accepted string.
    {
        String sqlStatement, select;
        
        try 
        {
 
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        }
        catch(ClassNotFoundException cnfex) 
        {
 
            System.out.println("Problem in loading or registering MS Access JDBC driver");
            cnfex.printStackTrace();
        }
        try 
        {
           connection = DriverManager.getConnection(dbURL); 

           statement = connection.createStatement();
           
           select = "(SELECT DonorID FROM tblDonors WHERE Username = \"" + user + "\")";
           
           sqlStatement = "INSERT INTO tblQuestionnaire(DonorID, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10, Q11, Q12, Q13, Q14, Q15, Q16, Q17, Q18, Q19, Q20, Q21, Q22, Q23, Q24," +
                            "Q25, Q26, Q27, Q28, Q29, Q30, Q31, Q32, Q33, Q34, Q35, Q36, Q37, Q38, Q39, Q40, Q41, Q42, Q43, Q44, Q45, Q46," +
                            "Q47, Q48, Q49, Q50, Q51, Q52, Q53, Q54, Q55, Q56, Q57)"
                            + " VALUES(" + select + " ," + q1 + ", " + q2 + ", " + q3 + ", " + q4 + ", " + q5 + ", " + q6 + ", " + q7 + ", " + q8 + ", " + q9
                            + ", " + q10 + ", " + q11 + ", " + q12 + ", " + q13 + ", " + q14 + ", " + q15 + ", " + q16 + ", " + q17 + ", " + q18
                            + ", " + q19 + ", " + q20 + ", " + q21 + ", " + q22 + ", " + q23 + ", " + q24 + ", " + q25 + ", " + q26 + ", " + q27
                            + ", " + q28 + ", " + q29 + ", " + q30 + ", " + q31 + ", " + q32 + ", " + q33 + ", " + q34 + ", " + q35 + ", " + q36
                            + ", " + q37 + ", " + q38 + ", " + q39 + ", " + q40 + ", " + q41 + ", " + q42 + ", " + q43 + ", " + q44 + ", " + q45
                            + ", " + q46 + ", " + q47 + ", " + q48 + ", " + q49 + ", " + q50 + ", " + q51 + ", " + q52 + ", " + q53 + ", " + q54
                            + ", " + q55 + ", " + q56 + ", " + q57 + ")";
            
            toTblQuestionnaire = connection.prepareStatement(sqlStatement);
            toTblQuestionnaire.executeUpdate();
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
        }
        
    }
    
    public int getID(String user)//Returns the ID of the last questionnaire completed by the user that has the same username as the accepted string.
    {
        int qID = 0;
        
        String sqlStatement = "SELECT TOP 1 QuestionnaireID FROM tblQuestionnaire WHERE DonorID = (SELECT DonorID FROM tblDonors WHERE Username = \"" 
                                + user + "\") ORDER BY QuestionnaireID DESC";
        try 
        {
            qnaireID = statement.executeQuery(sqlStatement);
            
            while(qnaireID.next())
            {
                qID = qnaireID.getInt(1);
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Questionnaire.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return qID;
    }
    
}
