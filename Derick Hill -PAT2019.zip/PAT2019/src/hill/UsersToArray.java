package hill;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;


public class UsersToArray 
{
    private Connection connection = null;
    private Statement statement = null;
    
    private ResultSet donors;
    private ResultSet nurses;
    private ResultSet questionnaireID;
    private ResultSet admins;    
    
    private Donor[] arrDonors = new Donor[100];
    private Nurse[] arrNurses = new Nurse[100];
        
    private int donorCount = 0;
    private int nurseCount = 0;   
    
    private final String msAccDB = "dbWCBS.accdb";
    private final String dbURL = "jdbc:ucanaccess://" + msAccDB;
    
    UsersToArray()//Instantiates a UsersToArray object, entering all records from tblDonors and tblNurses into two arrays of Donor and Nurse objects.
    {
        try 
        {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        }
        catch(ClassNotFoundException cnfex) 
        {
 
            System.out.println("Problem in loading or registering MS Access JDBC driver");
            cnfex.printStackTrace();
        }
        try 
        {
            connection = DriverManager.getConnection(dbURL); 

            statement = connection.createStatement();
            
            donors = statement.executeQuery("SELECT * FROM tblDonors");
            nurses = statement.executeQuery("SELECT * FROM tblNurses");
            
            while(donors.next())
            {
                arrDonors[donorCount] = new Donor(donors.getString(2), donors.getString(3), donors.getString(5), donors.getBoolean(4), 
                        donors.getDate(6), donors.getDouble(7), donors.getString(8), donors.getString(9));
                
                arrDonors[donorCount].donationsToArr();
                
                donorCount++;
            }
            
            while(nurses.next())
            {
                arrNurses[nurseCount] = new Nurse(nurses.getString(2), nurses.getString(3));
                
                nurseCount++;
            }
 
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
        }
    }
    
    public boolean usernameInDonors(String txtSetUsername)//Returns true is the accepted string’s value is found in the username field in tblDonors.
    {
        boolean inTable = false;
        try 
        {
            connection = DriverManager.getConnection(dbURL);
            
            statement = connection.createStatement();
            
            donors = statement.executeQuery("SELECT Username FROM tblDonors");
            
            while(donors.next())
            {
                if(txtSetUsername.equals(donors.getString(1)))
                {
                    inTable = true;
                }
            }             
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(UsersToArray.class.getName()).log(Level.SEVERE, null, ex);
        }
        return inTable;
    }
    
    public Donor donorAtUsername(String user)//Returns the Donor object in the array where the username has the same value as the accepted string.
    {
               
        Donor atUsername = new Donor("", "", "", false, null, 0, "", "");
        
        for(int i = 0; i < donorCount; i++)
        {
            if(arrDonors[i].getUsername().equals(user))
            {
                atUsername = arrDonors[i];
            }
        }
        
        return atUsername;
    }
    
    public Questionnaire questionnaireAtID(int qID)//Retrieves the record in tblQuestionnaire where the QuestionnaireID is equal to the accepted integer and returns it as a Questionnaire object.
    {
        Questionnaire questionnaire = new Questionnaire(false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
                    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
                    false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
                    false, false, false, false, false, false);
        try 
        {
            String sqlStatement = "SELECT * FROM tblQuestionnaire WHERE QuestionnaireID = " + qID;
            
            questionnaireID = statement.executeQuery(sqlStatement);
            
            while(questionnaireID.next())
            {
                questionnaire = new Questionnaire(questionnaireID.getBoolean(2), questionnaireID.getBoolean(3), questionnaireID.getBoolean(4), questionnaireID.getBoolean(5),
                        questionnaireID.getBoolean(6), questionnaireID.getBoolean(7), questionnaireID.getBoolean(8), questionnaireID.getBoolean(9), questionnaireID.getBoolean(10),
                        questionnaireID.getBoolean(11), questionnaireID.getBoolean(12), questionnaireID.getBoolean(13), questionnaireID.getBoolean(14), questionnaireID.getBoolean(15),
                        questionnaireID.getBoolean(16), questionnaireID.getBoolean(17), questionnaireID.getBoolean(18), questionnaireID.getBoolean(19), questionnaireID.getBoolean(20),
                        questionnaireID.getBoolean(21), questionnaireID.getBoolean(22), questionnaireID.getBoolean(23), questionnaireID.getBoolean(24), questionnaireID.getBoolean(25),
                        questionnaireID.getBoolean(26), questionnaireID.getBoolean(27), questionnaireID.getBoolean(28), questionnaireID.getBoolean(29), questionnaireID.getBoolean(30),
                        questionnaireID.getBoolean(31), questionnaireID.getBoolean(32), questionnaireID.getBoolean(33), questionnaireID.getBoolean(34), questionnaireID.getBoolean(35),
                        questionnaireID.getBoolean(36), questionnaireID.getBoolean(37), questionnaireID.getBoolean(38), questionnaireID.getBoolean(39), questionnaireID.getBoolean(40),
                        questionnaireID.getBoolean(41), questionnaireID.getBoolean(42), questionnaireID.getBoolean(43), questionnaireID.getBoolean(44), questionnaireID.getBoolean(45),
                        questionnaireID.getBoolean(46), questionnaireID.getBoolean(47), questionnaireID.getBoolean(48), questionnaireID.getBoolean(49), questionnaireID.getBoolean(50),
                        questionnaireID.getBoolean(51), questionnaireID.getBoolean(52), questionnaireID.getBoolean(53), questionnaireID.getBoolean(54), questionnaireID.getBoolean(55),
                        questionnaireID.getBoolean(56), questionnaireID.getBoolean(57), questionnaireID.getBoolean(58));
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(UsersToArray.class.getName()).log(Level.SEVERE, null, ex);
        }
        return questionnaire;
    }
    
    public String questionnaireInfoAtID(int qID)//Returns the answers to each question from the record in tblQuestionnaire that corresponds with the accepted ID value.
    {
        String results = "";
        
        try 
        {
            String sqlStatement = "SELECT * FROM tblQuestionnaire WHERE QuestionnaireID = " + qID;
            
            questionnaireID = statement.executeQuery(sqlStatement);
            
            while(questionnaireID.next())
            {
                for(int i = 1; i <= 57; i++)
                {
                    results = results + i + ". " + questionnaireID.getBoolean(i + 1) + "\n";
                }
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(UsersToArray.class.getName()).log(Level.SEVERE, null, ex);
        }
        return results;
    }
    
    public Donor donorFromQuestionnaire(int qID)//Returns a Donor object that has the values of the donor in tblDonors that corresponds with the questionnaire in tblQuestionnaire that has the same ID value as the integer accepted.
    {
        Donor donor = new Donor("", "", "", false, null, 0, "", "");
        
        String select = "SELECT DonorID FROM tblQuestionnaire WHERE QuestionnaireID = " + qID;
        
        String sqlStatement = "SELECT Username FROM tblDonors WHERE DonorID = (" + select + ")";
        
        String user = "";
        
        try 
        {
            donors = statement.executeQuery(sqlStatement);
            
            while(donors.next())
            {
                user = donors.getString(1);
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(UsersToArray.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        donor = donorAtUsername(user);
        
        return donor;
    }
    
    public boolean usernameInNurses(String txtSetUsername)//Returns true is the accepted string’s value is found in the username field in tblNurses.
    {
        boolean inTable = false;
        try 
        {
            connection = DriverManager.getConnection(dbURL);
            
            statement = connection.createStatement();
            
            nurses = statement.executeQuery("SELECT Username FROM tblNurses");
            
            while(nurses.next())
            {
                if(txtSetUsername.equals(nurses.getString(1)))
                {
                    inTable = true;
                }
            }             
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(UsersToArray.class.getName()).log(Level.SEVERE, null, ex);
        }
        return inTable;
    }
    
    public Admin getAdmin()//Returns an Admin object with the same values as that of the single record in tblAdmin.
    {
        Admin admin = new Admin("", "");
                        
        String sqlStatement = "SELECT TOP 1 Username, Password FROM tblAdmin ORDER BY AdminID";
        
        try 
        {
            admins = statement.executeQuery(sqlStatement);
            
            while(admins.next())
            {
                admin = new Admin(admins.getString(1), admins.getString(2));
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(UsersToArray.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return admin;
    }
}
