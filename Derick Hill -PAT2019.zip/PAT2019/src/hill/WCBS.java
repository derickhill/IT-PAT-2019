package hill;

public class WCBS 
{
    public static void main(String[]args)
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new PAT2019UI().setVisible(true);
            }
        });
    }
}
