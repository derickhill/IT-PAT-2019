package hill;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.text.*;
import java.sql.PreparedStatement;
import java.util.Date;

public class PAT2019UI extends javax.swing.JFrame
{

    public PAT2019UI() 
    {
        initComponents();
        
        pnlLogin.setVisible(true);
        pnlCreateProfile.setVisible(false);  
                
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlLogin = new javax.swing.JPanel();
        txtUsername = new javax.swing.JTextField();
        lblUsername = new javax.swing.JLabel();
        lblPassword = new javax.swing.JLabel();
        btnCreateProfile1 = new javax.swing.JButton();
        btnLogin = new javax.swing.JButton();
        txtPassword = new javax.swing.JPasswordField();
        lblUsernameLoginValidation = new javax.swing.JLabel();
        lblLoginValidation = new javax.swing.JLabel();
        lblPasswordLoginValidation = new javax.swing.JLabel();
        cmbxLoginAs = new javax.swing.JComboBox<>();
        lblLoginAs = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        pnlCreateProfile = new javax.swing.JPanel();
        lblFirstName = new javax.swing.JLabel();
        lblSurname = new javax.swing.JLabel();
        txtFirstName = new javax.swing.JTextField();
        txtSurname = new javax.swing.JTextField();
        lblDOB = new javax.swing.JLabel();
        lblSetUsername = new javax.swing.JLabel();
        lblSetPassword = new javax.swing.JLabel();
        lblConfirmPassword = new javax.swing.JLabel();
        txtSetPassword = new javax.swing.JPasswordField();
        txtConfirmPassword = new javax.swing.JPasswordField();
        dtpckrDOB = new org.jdesktop.swingx.JXDatePicker();
        txtSetUsername = new javax.swing.JTextField();
        btnCreateProfile2 = new javax.swing.JButton();
        txtIDNumber = new javax.swing.JTextField();
        lblIDNumber = new javax.swing.JLabel();
        cmbxSex = new javax.swing.JComboBox<>();
        lblSex = new javax.swing.JLabel();
        btnLogIn = new javax.swing.JButton();
        lblAlreadyHaveAProfile = new javax.swing.JLabel();
        lblFirstNameValidation = new javax.swing.JLabel();
        lblSurnameValidation = new javax.swing.JLabel();
        lblUsernameValidation = new javax.swing.JLabel();
        lblIDValidation = new javax.swing.JLabel();
        lblDOBValidation = new javax.swing.JLabel();
        lblPasswordValidation = new javax.swing.JLabel();
        lblConfirmPasswordValidation = new javax.swing.JLabel();
        lblWeightValidation = new javax.swing.JLabel();
        lblWeight = new javax.swing.JLabel();
        txtWeight = new javax.swing.JTextField();
        lblKG = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1000, 600));
        getContentPane().setLayout(null);

        pnlLogin.setMinimumSize(new java.awt.Dimension(500, 300));

        lblUsername.setBackground(new java.awt.Color(255, 51, 51));
        lblUsername.setText("Username");

        lblPassword.setText("Password");

        btnCreateProfile1.setText("Create profile");
        btnCreateProfile1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateProfile1ActionPerformed(evt);
            }
        });

        btnLogin.setText("Login");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });

        cmbxLoginAs.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Donor", "Nurse", "Admin" }));

        lblLoginAs.setText("Login as:");

        jLabel1.setFont(new java.awt.Font("Terminator Two", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setText("WCBS");

        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 51, 51));
        jLabel2.setText("Be a hero.");

        javax.swing.GroupLayout pnlLoginLayout = new javax.swing.GroupLayout(pnlLogin);
        pnlLogin.setLayout(pnlLoginLayout);
        pnlLoginLayout.setHorizontalGroup(
            pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLoginLayout.createSequentialGroup()
                .addGap(361, 361, 361)
                .addGroup(pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlLoginLayout.createSequentialGroup()
                        .addGroup(pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblPassword)
                            .addComponent(lblUsername))
                        .addGap(38, 38, 38)
                        .addGroup(pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtPassword)
                            .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblPasswordLoginValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlLoginLayout.createSequentialGroup()
                                .addComponent(lblUsernameLoginValidation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(17, 17, 17))))
                    .addGroup(pnlLoginLayout.createSequentialGroup()
                        .addGroup(pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlLoginLayout.createSequentialGroup()
                                .addGap(73, 73, 73)
                                .addComponent(btnLogin))
                            .addComponent(lblLoginValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 413, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnlLoginLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(lblLoginAs)
                                .addGap(18, 18, 18)
                                .addComponent(cmbxLoginAs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(226, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLoginLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLoginLayout.createSequentialGroup()
                        .addGroup(pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(357, 357, 357))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLoginLayout.createSequentialGroup()
                        .addComponent(btnCreateProfile1)
                        .addGap(81, 81, 81))))
        );
        pnlLoginLayout.setVerticalGroup(
            pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlLoginLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 126, Short.MAX_VALUE)
                .addGroup(pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbxLoginAs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLoginAs))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblLoginValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlLoginLayout.createSequentialGroup()
                        .addGroup(pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblUsername))
                        .addGap(18, 18, 18)
                        .addGroup(pnlLoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblPassword)
                            .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlLoginLayout.createSequentialGroup()
                        .addComponent(lblUsernameLoginValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblPasswordLoginValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(24, 24, 24)
                .addComponent(btnLogin)
                .addGap(98, 98, 98)
                .addComponent(btnCreateProfile1)
                .addGap(77, 77, 77))
        );

        lblUsername.getAccessibleContext().setAccessibleDescription("");

        getContentPane().add(pnlLogin);
        pnlLogin.setBounds(0, 0, 1000, 600);

        lblFirstName.setText("First name:");

        lblSurname.setText("Surname:");

        lblDOB.setText("Date of birth:");

        lblSetUsername.setText("Username:");

        lblSetPassword.setText("Password:");

        lblConfirmPassword.setText("Confirm password:");

        txtSetPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSetPasswordActionPerformed(evt);
            }
        });

        txtSetUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSetUsernameActionPerformed(evt);
            }
        });

        btnCreateProfile2.setText("Create profile");
        btnCreateProfile2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateProfile2ActionPerformed(evt);
            }
        });

        lblIDNumber.setText("ID number:");

        cmbxSex.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        cmbxSex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbxSexActionPerformed(evt);
            }
        });

        lblSex.setText("Sex:");

        btnLogIn.setText("Log in");
        btnLogIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogInActionPerformed(evt);
            }
        });

        lblAlreadyHaveAProfile.setText("Already have a profile?");

        lblWeight.setText("Weight:");

        lblKG.setText("kg");

        javax.swing.GroupLayout pnlCreateProfileLayout = new javax.swing.GroupLayout(pnlCreateProfile);
        pnlCreateProfile.setLayout(pnlCreateProfileLayout);
        pnlCreateProfileLayout.setHorizontalGroup(
            pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCreateProfileLayout.createSequentialGroup()
                .addGap(246, 246, 246)
                .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(lblSurname)
                        .addComponent(lblSetPassword)
                        .addComponent(lblConfirmPassword)
                        .addComponent(lblFirstName)
                        .addComponent(lblDOB)
                        .addComponent(lblIDNumber)
                        .addComponent(lblSex)
                        .addComponent(lblWeight))
                    .addGroup(pnlCreateProfileLayout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(lblSetUsername)))
                .addGap(21, 21, 21)
                .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCreateProfileLayout.createSequentialGroup()
                        .addComponent(cmbxSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pnlCreateProfileLayout.createSequentialGroup()
                        .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(dtpckrDOB, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnCreateProfile2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtFirstName, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtSetPassword, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtSurname, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtConfirmPassword, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtSetUsername, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtIDNumber, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlCreateProfileLayout.createSequentialGroup()
                                .addComponent(txtWeight, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblKG)))
                        .addGap(47, 47, 47)
                        .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblUsernameValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 472, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblSurnameValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblFirstNameValidation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblIDValidation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblDOBValidation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblWeightValidation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblPasswordValidation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblConfirmPasswordValidation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
            .addGroup(pnlCreateProfileLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblAlreadyHaveAProfile)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLogIn)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlCreateProfileLayout.setVerticalGroup(
            pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCreateProfileLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblFirstNameValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblFirstName)
                        .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(22, 22, 22)
                .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblSurname)
                        .addComponent(txtSurname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblSurnameValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCreateProfileLayout.createSequentialGroup()
                        .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblSetUsername)
                            .addComponent(txtSetUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11)
                        .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmbxSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblSex)))
                    .addComponent(lblUsernameValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblIDValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtIDNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblIDNumber)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblDOB)
                        .addComponent(dtpckrDOB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblDOBValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblWeight)
                        .addComponent(txtWeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblKG))
                    .addComponent(lblWeightValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblSetPassword)
                        .addComponent(txtSetPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblPasswordValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblConfirmPasswordValidation, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblConfirmPassword)
                        .addComponent(txtConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(25, 25, 25)
                .addComponent(btnCreateProfile2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(pnlCreateProfileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAlreadyHaveAProfile)
                    .addComponent(btnLogIn))
                .addGap(44, 44, 44))
        );

        getContentPane().add(pnlCreateProfile);
        pnlCreateProfile.setBounds(0, 0, 1032, 464);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private String getAge()
    {
        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        dob.setTime(dtpckrDOB.getDate()); 

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR))
        {
            age--; 
        }

        Integer ageInt = age;
        String ageS = ageInt.toString();

        return ageS;  
    }
    
    public static Boolean checkLuhn(BigInteger identities)
    {
        char[] idchars = identities.toString().toCharArray();
        int sum = 0;
        // loop over each digit right-to-left, including the check-digit
        for (int i = 1; i <= idchars.length; i++) 
        {
            int digit = Character.getNumericValue(idchars[idchars.length - i]);
            if ((i % 2) != 0) 
            {
                sum += digit;
            } 
            else 
            {
                sum += digit < 5 ? digit * 2 : digit * 2 - 9;
            }
        }
        return (sum % 10) == 0;
    }
    
    private void btnCreateProfile1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateProfile1ActionPerformed
        pnlCreateProfile.setVisible(true);
        pnlLogin.setVisible(false);
    }//GEN-LAST:event_btnCreateProfile1ActionPerformed

    private void btnLogInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogInActionPerformed
        pnlCreateProfile.setVisible(false);
        pnlLogin.setVisible(true);
    }//GEN-LAST:event_btnLogInActionPerformed

    private void cmbxSexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbxSexActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbxSexActionPerformed

    private void btnCreateProfile2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateProfile2ActionPerformed
        Connection connection = null;
        Statement statement = null;
        ResultSet allUsernames = null;
        PreparedStatement inputToDonors = null;
        
        UsersToArray usersToArray = new UsersToArray();
        
        try 
        {
 
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        }
        catch(ClassNotFoundException cnfex) {
 
            System.out.println("Problem in loading or registering MS Access JDBC driver");
            cnfex.printStackTrace();
        }
        try 
        {
 
            String msAccDB = "dbWCBS.accdb";
            String dbURL = "jdbc:ucanaccess://" + msAccDB; 
 
            connection = DriverManager.getConnection(dbURL); 

            statement = connection.createStatement();
            
            
 
        }
        catch(SQLException sqlex){
            sqlex.printStackTrace();
        }
        
        boolean name = false, surname = false, id = false, dob = false, weight = false, username = false, password1 = false, password2 = false;
        
        boolean sex;
        
        String chosenSex = (String)cmbxSex.getSelectedItem();
        
        if(chosenSex.equalsIgnoreCase("Male"))
        {
            sex = true;
        }
        else
        {
            sex = false;
        }
        
        lblFirstNameValidation.setText("");
        lblSurnameValidation.setText("");
        lblIDValidation.setText("");
        lblDOBValidation.setText("");
        lblWeightValidation.setText("");
        lblUsernameValidation.setText("");
        lblPasswordValidation.setText("");
        lblConfirmPasswordValidation.setText("");
        
        if(txtFirstName.getText().equalsIgnoreCase(""))
        {
            lblFirstNameValidation.setText("Please enter your name.");
        }
        else
        {
            name = true;
        }
        
        if(txtSurname.getText().equalsIgnoreCase(""))
        {
            lblSurnameValidation.setText("Please enter your surname.");
        }
        else
        {
            surname = true;
        }
        
        
        
        if(txtSetUsername.getText().equalsIgnoreCase(""))
        {
            lblUsernameValidation.setText("Please enter a username.");
        }
        else
        {
            
        
            if(usersToArray.usernameInDonors(txtSetUsername.getText()))
            {
                lblUsernameValidation.setText("Username taken.");
            }
            else
            {
                username = true;
            }             
        }
        
        if(txtIDNumber.getText().equalsIgnoreCase(""))
        {
           lblIDValidation.setText("Please enter your ID number."); 
        }
        else
        {
            for(int i = 0; i < txtIDNumber.getText().length(); i++)
            {
                if(txtIDNumber.getText().length() == 13 && Character.isDigit(txtIDNumber.getText().charAt(i)))
                {
                    BigInteger bigID = new BigInteger(txtIDNumber.getText());
                
                    if(checkLuhn(bigID) == true)
                    {
                        id = true;
                    }
                    else
                    {
                        lblIDValidation.setText("Please enter a valid ID number."); 
                    }
                }
                else
                {
                    lblIDValidation.setText("Your ID number must be 13 digits long.");
                }
            }
        }
        
        if(txtWeight.getText().equalsIgnoreCase(""))
        {
            lblWeightValidation.setText("Please enter your weight.");
        }
        else
        {
            for(int i = 0; i < txtWeight.getText().length(); i++)
            {
               if(Character.isDigit(txtWeight.getText().charAt(i)) || txtWeight.getText().charAt(i) == ',' || txtWeight.getText().charAt(i) == '.')
                {
                    if(Double.parseDouble(txtWeight.getText()) >= 50)
                    {
                        weight = true;
                    }
                    else
                    {
                        lblWeightValidation.setText("You must weigh 50kg or more.");
                        weight = false;
                    }
                }
                else
                {
                    lblWeightValidation.setText("Please enter a numerical value.");
                } 
            }
        }
        
        if(dtpckrDOB.getDate() == null)
        {
            lblDOBValidation.setText("Please choose a date.");
        }
        else
        {
            if(Integer.parseInt(getAge()) < 16)
            {
                lblDOBValidation.setText("You must be at least 16 to donate blood.");
            }
            else
            {
                 dob = true;
            }
        }
        
        String p1, p2;
        p1 = String.valueOf(txtSetPassword.getPassword());
        p2 = String.valueOf(txtConfirmPassword.getPassword());
        
        if(p1.equalsIgnoreCase(""))
        {
            lblPasswordValidation.setText("Please enter a password.");
        }
        else
        {
            password1 = true;
        }
        
        if(p2.equalsIgnoreCase(""))
        {
            lblConfirmPasswordValidation.setText("Please confirm password.");
        }
        else 
        {
            if(p2.equals(p1))
            {
                password2 = true;
            }
            else
            {
                lblConfirmPasswordValidation.setText("Passwords do not match.");
            }
        }
                        
               
        
                                
        if(name && surname && id && dob && weight && username && password1 && password2)
        {
             
            java.util.Date utilDate = dtpckrDOB.getDate();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            final String stringDate= dateFormat.format(utilDate);
            final java.sql.Date sqlDate=  java.sql.Date.valueOf(stringDate);
            
            double weightDouble = Double.parseDouble(txtWeight.getText());    
            
            Donor newDonor = new Donor(txtFirstName.getText(), txtSurname.getText(), txtIDNumber.getText(), sex, 
                        sqlDate, weightDouble, txtSetUsername.getText(), p1);
                
            newDonor.toTable();
                                
            pnlCreateProfile.setVisible(false);
            pnlLogin.setVisible(true);
               
            lblLoginValidation.setText("Profile created.");
        }
       
    }//GEN-LAST:event_btnCreateProfile2ActionPerformed

    private void txtSetPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSetPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSetPasswordActionPerformed

    private void txtSetUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSetUsernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSetUsernameActionPerformed

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
        lblPasswordLoginValidation.setText("");
        lblUsernameLoginValidation.setText("");
        lblLoginValidation.setText("");
        
        Connection connection = null;
        Statement statement = null;
        ResultSet login = null;
                
        try 
        {
 
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        }
        catch(ClassNotFoundException cnfex) {
 
            System.out.println("Problem in loading or registering MS Access JDBC driver");
            cnfex.printStackTrace();
        }
        try 
        {
            String msAccDB = "dbWCBS.accdb";
            String dbURL = "jdbc:ucanaccess://" + msAccDB; 
 
            connection = DriverManager.getConnection(dbURL); 

            statement = connection.createStatement();
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
        }
        try 
        {
            String loginAs = (String)cmbxLoginAs.getSelectedItem();
            String password = String.valueOf(txtPassword.getPassword());
            String username = txtUsername.getText();
                       
            if(loginAs.equalsIgnoreCase("Nurse"))
            {
                login = statement.executeQuery("SELECT Username,Password FROM tblNurses");
            }
            else
            {
                if(loginAs.equalsIgnoreCase("Donor"))
                {
                    login = statement.executeQuery("SELECT Username,Password FROM tblDonors");
                }
                else
                {
                    login = statement.executeQuery("SELECT TOP 1 Username,Password FROM tblAdmin ORDER BY AdminID");
                }
            }
                
            if(!(username.equalsIgnoreCase("")) && !(password.equalsIgnoreCase("")))
            {                   
                while(login.next())
                {
                    if(username.equals(login.getString(1)) && password.equals(login.getString(2)))
                    {                   
                        if(loginAs.equalsIgnoreCase("Donor"))
                        {            
                            java.awt.EventQueue.invokeLater(new Runnable() 
                            {
                                public void run() 
                                {
                                    new DonorMenu(username).setVisible(true);
                                }
                            });
                        }  
                        else
                        {
                            if(loginAs.equalsIgnoreCase("Nurse"))
                            {
                                java.awt.EventQueue.invokeLater(new Runnable() 
                                {
                                    public void run() 
                                    {   
                                        new NurseMenu(username).setVisible(true);
                                    }
                                });
                            }
                            else
                            {
                                java.awt.EventQueue.invokeLater(new Runnable() 
                                {
                                    public void run() 
                                    {   
                                        new AdminMenu(username).setVisible(true);
                                    }
                                });
                            }     
                        }
                            
                        this.dispose();
                    }
                    else
                    {
                        lblLoginValidation.setText("Username and password do not match.");
                    }
                }
            }
            else
            {
                if(username.equalsIgnoreCase(""))
                {
                    lblUsernameLoginValidation.setText("Please enter your username.");
                }
                
                if(password.equalsIgnoreCase(""))
                {
                    lblPasswordLoginValidation.setText("Please enter your password.");
                }
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(PAT2019UI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnLoginActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCreateProfile1;
    private javax.swing.JButton btnCreateProfile2;
    private javax.swing.JButton btnLogIn;
    private javax.swing.JButton btnLogin;
    private javax.swing.JComboBox<String> cmbxLoginAs;
    private javax.swing.JComboBox<String> cmbxSex;
    private org.jdesktop.swingx.JXDatePicker dtpckrDOB;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel lblAlreadyHaveAProfile;
    private javax.swing.JLabel lblConfirmPassword;
    private javax.swing.JLabel lblConfirmPasswordValidation;
    private javax.swing.JLabel lblDOB;
    private javax.swing.JLabel lblDOBValidation;
    private javax.swing.JLabel lblFirstName;
    private javax.swing.JLabel lblFirstNameValidation;
    private javax.swing.JLabel lblIDNumber;
    private javax.swing.JLabel lblIDValidation;
    private javax.swing.JLabel lblKG;
    private javax.swing.JLabel lblLoginAs;
    private javax.swing.JLabel lblLoginValidation;
    private javax.swing.JLabel lblPassword;
    private javax.swing.JLabel lblPasswordLoginValidation;
    private javax.swing.JLabel lblPasswordValidation;
    private javax.swing.JLabel lblSetPassword;
    private javax.swing.JLabel lblSetUsername;
    private javax.swing.JLabel lblSex;
    private javax.swing.JLabel lblSurname;
    private javax.swing.JLabel lblSurnameValidation;
    private javax.swing.JLabel lblUsername;
    private javax.swing.JLabel lblUsernameLoginValidation;
    private javax.swing.JLabel lblUsernameValidation;
    private javax.swing.JLabel lblWeight;
    private javax.swing.JLabel lblWeightValidation;
    private javax.swing.JPanel pnlCreateProfile;
    private javax.swing.JPanel pnlLogin;
    private javax.swing.JPasswordField txtConfirmPassword;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtIDNumber;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JPasswordField txtSetPassword;
    private javax.swing.JTextField txtSetUsername;
    private javax.swing.JTextField txtSurname;
    private javax.swing.JTextField txtUsername;
    private javax.swing.JTextField txtWeight;
    // End of variables declaration//GEN-END:variables
}
