package hill;
        
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class Nurse extends User
{
    private PreparedStatement nurse;
    
    private Connection connection = null;
    private Statement statement = null;
    
    private final String msAccDB = "dbWCBS.accdb";
    private final String dbURL = "jdbc:ucanaccess://" + msAccDB; 
    
    Nurse(String a, String b)//Instantiates a Nurse object using the accepted strings as username and password.
    {
        super(a,b);
    }
    
    public void toTable()//Inserts the object’s values into tblNurses as a new record.
    {
        String sqlStatement;
        
        try 
        {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        }
        catch(ClassNotFoundException cnfex) 
        {
 
            System.out.println("Problem in loading or registering MS Access JDBC driver");
            cnfex.printStackTrace();
        }
        try 
        {             
           connection = DriverManager.getConnection(dbURL); 

           statement = connection.createStatement();
                                
           sqlStatement = "INSERT INTO tblNurses(Username, Password)"
                            + " VALUES( \"" + username + "\" , \"" + password + "\" )";
            
           nurse = connection.prepareStatement(sqlStatement);
           nurse.executeUpdate();
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
        }
    }
}
