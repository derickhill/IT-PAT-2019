package hill;

public class DonorMenu extends javax.swing.JFrame {

    String username;
    
    UsersToArray toArr = new UsersToArray();
    
    public DonorMenu(String user) 
    {
        username = user;
        
        initComponents();
        
        pnlDonorMenu.setVisible(true);
        pnlCompleteQuestionnaire.setVisible(false);
        pnlHelp.setVisible(false);
        pnlUpdateDetails.setVisible(false);
        pnlQ1.setVisible(false);
        pnlQ2.setVisible(false);
        pnlQ3.setVisible(false);
        pnlQ4.setVisible(false);
        pnlQ5.setVisible(false);
        pnlQ6.setVisible(false);
        pnlQ7.setVisible(false);
        pnlQ8.setVisible(false);
        pnlQ9.setVisible(false);
        pnlProcessQuestionnaire.setVisible(false);
    }
    
    public String getUser()
    {
        return username;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlDonorMenu = new javax.swing.JPanel();
        btnLogOut = new javax.swing.JButton();
        btnCompleteQuestionnaire = new javax.swing.JButton();
        btnUpdateDetails = new javax.swing.JButton();
        btnHelp = new javax.swing.JButton();
        lblQuestionnaireValidation = new javax.swing.JLabel();
        lblDonorMenuValidation = new javax.swing.JLabel();
        btnLogOut1 = new javax.swing.JButton();
        pnlCompleteQuestionnaire = new javax.swing.JPanel();
        btnBack = new javax.swing.JButton();
        btnStart = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        pnlUpdateDetails = new javax.swing.JPanel();
        btnBack1 = new javax.swing.JButton();
        txtWeight = new javax.swing.JTextField();
        txtSurname = new javax.swing.JTextField();
        lblKG = new javax.swing.JLabel();
        lblWeightValidation = new javax.swing.JLabel();
        lblSurnameValidation = new javax.swing.JLabel();
        lblSetWeight = new javax.swing.JLabel();
        lblSetSurname = new javax.swing.JLabel();
        btnUpdate = new javax.swing.JButton();
        lblUpdateDetails = new javax.swing.JLabel();
        pnlHelp = new javax.swing.JPanel();
        btnBack2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtHelp = new javax.swing.JTextArea();
        pnlQ1 = new javax.swing.JPanel();
        btnNext = new javax.swing.JButton();
        btnBackToMenu = new javax.swing.JButton();
        q1 = new javax.swing.JCheckBox();
        q2 = new javax.swing.JCheckBox();
        q3 = new javax.swing.JCheckBox();
        q4 = new javax.swing.JCheckBox();
        q5 = new javax.swing.JCheckBox();
        q6 = new javax.swing.JCheckBox();
        lblQ1 = new javax.swing.JLabel();
        lblQ2 = new javax.swing.JLabel();
        lblQ3 = new javax.swing.JLabel();
        lblQ4 = new javax.swing.JLabel();
        lblQ5 = new javax.swing.JLabel();
        lblQ6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        pnlQ2 = new javax.swing.JPanel();
        btnNext1 = new javax.swing.JButton();
        btnPrevious1 = new javax.swing.JButton();
        btnBackToMenu1 = new javax.swing.JButton();
        q7 = new javax.swing.JCheckBox();
        q8 = new javax.swing.JCheckBox();
        q9 = new javax.swing.JCheckBox();
        lblQ7 = new javax.swing.JLabel();
        lblQ8 = new javax.swing.JLabel();
        lblQ9 = new javax.swing.JLabel();
        pnlQ3 = new javax.swing.JPanel();
        btnNext2 = new javax.swing.JButton();
        btnPrevious2 = new javax.swing.JButton();
        btnBackToMenu2 = new javax.swing.JButton();
        q10 = new javax.swing.JCheckBox();
        q11 = new javax.swing.JCheckBox();
        q12 = new javax.swing.JCheckBox();
        q13 = new javax.swing.JCheckBox();
        q14 = new javax.swing.JCheckBox();
        q15 = new javax.swing.JCheckBox();
        q16 = new javax.swing.JCheckBox();
        q17 = new javax.swing.JCheckBox();
        lblQ10 = new javax.swing.JLabel();
        lblQ11 = new javax.swing.JLabel();
        lblQ12 = new javax.swing.JLabel();
        lblQ13 = new javax.swing.JLabel();
        lblQ14 = new javax.swing.JLabel();
        lblQ15 = new javax.swing.JLabel();
        lblQ16 = new javax.swing.JLabel();
        lblQ17 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        pnlQ4 = new javax.swing.JPanel();
        btnNext3 = new javax.swing.JButton();
        btnPrevious3 = new javax.swing.JButton();
        btnBackToMenu3 = new javax.swing.JButton();
        q18 = new javax.swing.JCheckBox();
        q19 = new javax.swing.JCheckBox();
        q20 = new javax.swing.JCheckBox();
        q21 = new javax.swing.JCheckBox();
        q22 = new javax.swing.JCheckBox();
        q23 = new javax.swing.JCheckBox();
        q24 = new javax.swing.JCheckBox();
        lblQ18 = new javax.swing.JLabel();
        lblQ19 = new javax.swing.JLabel();
        lblQ20 = new javax.swing.JLabel();
        lblQ21 = new javax.swing.JLabel();
        lblQ22 = new javax.swing.JLabel();
        lblQ23 = new javax.swing.JLabel();
        lblQ24 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        pnlQ5 = new javax.swing.JPanel();
        btnNext4 = new javax.swing.JButton();
        btnPrevious4 = new javax.swing.JButton();
        btnBackToMenu4 = new javax.swing.JButton();
        q25 = new javax.swing.JCheckBox();
        q26 = new javax.swing.JCheckBox();
        q27 = new javax.swing.JCheckBox();
        q28 = new javax.swing.JCheckBox();
        q29 = new javax.swing.JCheckBox();
        q30 = new javax.swing.JCheckBox();
        q31 = new javax.swing.JCheckBox();
        q32 = new javax.swing.JCheckBox();
        lblQ25 = new javax.swing.JLabel();
        lblQ26 = new javax.swing.JLabel();
        lblQ27 = new javax.swing.JLabel();
        lblQ28 = new javax.swing.JLabel();
        lblQ29 = new javax.swing.JLabel();
        lblQ30 = new javax.swing.JLabel();
        lblQ31 = new javax.swing.JLabel();
        lblQ32 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        pnlQ6 = new javax.swing.JPanel();
        btnNext5 = new javax.swing.JButton();
        btnPrevious5 = new javax.swing.JButton();
        btnBackToMenu5 = new javax.swing.JButton();
        q33 = new javax.swing.JCheckBox();
        q34 = new javax.swing.JCheckBox();
        q35 = new javax.swing.JCheckBox();
        q36 = new javax.swing.JCheckBox();
        q37 = new javax.swing.JCheckBox();
        q38 = new javax.swing.JCheckBox();
        q39 = new javax.swing.JCheckBox();
        q40 = new javax.swing.JCheckBox();
        lblQ33 = new javax.swing.JLabel();
        lblQ34 = new javax.swing.JLabel();
        lblQ35 = new javax.swing.JLabel();
        lblQ36 = new javax.swing.JLabel();
        lblQ37 = new javax.swing.JLabel();
        lblQ38 = new javax.swing.JLabel();
        lblQ39 = new javax.swing.JLabel();
        lblQ40 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        pnlQ7 = new javax.swing.JPanel();
        btnNext6 = new javax.swing.JButton();
        btnPrevious6 = new javax.swing.JButton();
        btnBackToMenu6 = new javax.swing.JButton();
        q41 = new javax.swing.JCheckBox();
        q42 = new javax.swing.JCheckBox();
        q43 = new javax.swing.JCheckBox();
        q44 = new javax.swing.JCheckBox();
        q45 = new javax.swing.JCheckBox();
        q46 = new javax.swing.JCheckBox();
        q47 = new javax.swing.JCheckBox();
        q48 = new javax.swing.JCheckBox();
        lblQ41 = new javax.swing.JLabel();
        lblQ42 = new javax.swing.JLabel();
        lblQ43 = new javax.swing.JLabel();
        lblQ44 = new javax.swing.JLabel();
        lblQ45 = new javax.swing.JLabel();
        lblQ46 = new javax.swing.JLabel();
        lblQ47 = new javax.swing.JLabel();
        lblQ48 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        pnlQ8 = new javax.swing.JPanel();
        btnNext7 = new javax.swing.JButton();
        btnPrevious7 = new javax.swing.JButton();
        btnBackToMenu7 = new javax.swing.JButton();
        q49 = new javax.swing.JCheckBox();
        q50 = new javax.swing.JCheckBox();
        q51 = new javax.swing.JCheckBox();
        q52 = new javax.swing.JCheckBox();
        q53 = new javax.swing.JCheckBox();
        q54 = new javax.swing.JCheckBox();
        lblQ49 = new javax.swing.JLabel();
        lblQ50 = new javax.swing.JLabel();
        lblQ51 = new javax.swing.JLabel();
        lblQ52 = new javax.swing.JLabel();
        lblQ53 = new javax.swing.JLabel();
        lblQ54 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        pnlQ9 = new javax.swing.JPanel();
        btnNext8 = new javax.swing.JButton();
        btnPrevious8 = new javax.swing.JButton();
        q55 = new javax.swing.JCheckBox();
        q56 = new javax.swing.JCheckBox();
        q57 = new javax.swing.JCheckBox();
        lblQ55 = new javax.swing.JLabel();
        lblQ56 = new javax.swing.JLabel();
        lblQ57 = new javax.swing.JLabel();
        btnBackToMenu9 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        pnlProcessQuestionnaire = new javax.swing.JPanel();
        btnBackToMenu8 = new javax.swing.JButton();
        lblProcessQuestionnaire = new javax.swing.JLabel();
        btnPrevious9 = new javax.swing.JButton();
        btnProcessQuestionnaire = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(100, 100));
        setPreferredSize(new java.awt.Dimension(1000, 600));
        getContentPane().setLayout(null);

        pnlDonorMenu.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnLogOut.setText("Log Out");
        btnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOutActionPerformed(evt);
            }
        });

        btnCompleteQuestionnaire.setText("Complete Questionnaire");
        btnCompleteQuestionnaire.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCompleteQuestionnaireActionPerformed(evt);
            }
        });

        btnUpdateDetails.setText("Update Details");
        btnUpdateDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateDetailsActionPerformed(evt);
            }
        });

        btnHelp.setText("Help");
        btnHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHelpActionPerformed(evt);
            }
        });

        btnLogOut1.setText("Log Out");
        btnLogOut1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOut1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlDonorMenuLayout = new javax.swing.GroupLayout(pnlDonorMenu);
        pnlDonorMenu.setLayout(pnlDonorMenuLayout);
        pnlDonorMenuLayout.setHorizontalGroup(
            pnlDonorMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDonorMenuLayout.createSequentialGroup()
                .addGap(243, 243, 243)
                .addComponent(lblDonorMenuValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlDonorMenuLayout.createSequentialGroup()
                .addGroup(pnlDonorMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlDonorMenuLayout.createSequentialGroup()
                        .addGap(329, 329, 329)
                        .addGroup(pnlDonorMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnCompleteQuestionnaire, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnUpdateDetails, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnHelp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                        .addComponent(lblQuestionnaireValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlDonorMenuLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnLogOut1)
                        .addGap(54, 54, 54)
                        .addComponent(btnLogOut)))
                .addGap(44, 44, 44))
        );
        pnlDonorMenuLayout.setVerticalGroup(
            pnlDonorMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDonorMenuLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(pnlDonorMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLogOut)
                    .addComponent(btnLogOut1))
                .addGap(40, 40, 40)
                .addComponent(lblDonorMenuValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlDonorMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCompleteQuestionnaire)
                    .addComponent(lblQuestionnaireValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(btnUpdateDetails)
                .addGap(36, 36, 36)
                .addComponent(btnHelp)
                .addContainerGap(341, Short.MAX_VALUE))
        );

        getContentPane().add(pnlDonorMenu);
        pnlDonorMenu.setBounds(0, 0, 1000, 600);

        pnlCompleteQuestionnaire.setMinimumSize(new java.awt.Dimension(871, 474));
        pnlCompleteQuestionnaire.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel1.setText("Please read all questions carefully and answer honestly.");

        javax.swing.GroupLayout pnlCompleteQuestionnaireLayout = new javax.swing.GroupLayout(pnlCompleteQuestionnaire);
        pnlCompleteQuestionnaire.setLayout(pnlCompleteQuestionnaireLayout);
        pnlCompleteQuestionnaireLayout.setHorizontalGroup(
            pnlCompleteQuestionnaireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCompleteQuestionnaireLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(btnBack)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlCompleteQuestionnaireLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlCompleteQuestionnaireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCompleteQuestionnaireLayout.createSequentialGroup()
                        .addGap(209, 209, 209)
                        .addComponent(btnStart))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(169, 169, 169))
        );
        pnlCompleteQuestionnaireLayout.setVerticalGroup(
            pnlCompleteQuestionnaireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCompleteQuestionnaireLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(btnBack)
                .addGap(172, 172, 172)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnStart)
                .addContainerGap(276, Short.MAX_VALUE))
        );

        getContentPane().add(pnlCompleteQuestionnaire);
        pnlCompleteQuestionnaire.setBounds(0, 0, 870, 600);

        pnlUpdateDetails.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnBack1.setText("Back");
        btnBack1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBack1ActionPerformed(evt);
            }
        });

        txtWeight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtWeightActionPerformed(evt);
            }
        });

        lblKG.setText("kg");

        lblSetWeight.setText("Set weight to:");

        lblSetSurname.setText("Set surname to:");

        btnUpdate.setText("Update details");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlUpdateDetailsLayout = new javax.swing.GroupLayout(pnlUpdateDetails);
        pnlUpdateDetails.setLayout(pnlUpdateDetailsLayout);
        pnlUpdateDetailsLayout.setHorizontalGroup(
            pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(btnBack1))
                    .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                        .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                                .addGap(364, 364, 364)
                                .addComponent(lblSetSurname))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUpdateDetailsLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(lblSetWeight)))
                        .addGap(18, 18, 18)
                        .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtSurname, javax.swing.GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE)
                            .addComponent(txtWeight))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblKG)
                        .addGap(43, 43, 43)
                        .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblWeightValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblSurnameValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                        .addGap(422, 422, 422)
                        .addComponent(btnUpdate)))
                .addContainerGap(167, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUpdateDetailsLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblUpdateDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(378, 378, 378))
        );
        pnlUpdateDetailsLayout.setVerticalGroup(
            pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(btnBack1)
                .addGap(113, 113, 113)
                .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblWeightValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtWeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblKG)
                        .addComponent(lblSetWeight)))
                .addGap(44, 44, 44)
                .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSurnameValidation, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtSurname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblSetSurname)))
                .addGap(30, 30, 30)
                .addComponent(btnUpdate)
                .addGap(28, 28, 28)
                .addComponent(lblUpdateDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(208, Short.MAX_VALUE))
        );

        getContentPane().add(pnlUpdateDetails);
        pnlUpdateDetails.setBounds(0, 0, 870, 460);

        pnlHelp.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnBack2.setText("Back");
        btnBack2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBack2ActionPerformed(evt);
            }
        });

        txtHelp.setColumns(20);
        txtHelp.setRows(5);
        txtHelp.setText("If you would like to donate blood, please select \"Complete Questionnaire\" and answer all\nthe questions.\nYou will be provided with a code that you need to give to the nurse on duty so that your blood\nsafety can be evaluated.\n\n\nIf you would like to update your details in the event of surname change or weight loss/gain,\nselect \"Update Details\" and fill in your new information.\n\n");
        jScrollPane1.setViewportView(txtHelp);

        javax.swing.GroupLayout pnlHelpLayout = new javax.swing.GroupLayout(pnlHelp);
        pnlHelp.setLayout(pnlHelpLayout);
        pnlHelpLayout.setHorizontalGroup(
            pnlHelpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHelpLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(btnBack2)
                .addGap(917, 917, 917))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHelpLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 764, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(64, 64, 64))
        );
        pnlHelpLayout.setVerticalGroup(
            pnlHelpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHelpLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(btnBack2)
                .addGap(57, 57, 57)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(pnlHelp);
        pnlHelp.setBounds(0, 0, 870, 470);

        pnlQ1.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnNext.setText("Next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnBackToMenu.setText("Back to Menu");
        btnBackToMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMenuActionPerformed(evt);
            }
        });

        q2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q2ActionPerformed(evt);
            }
        });

        q3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q3ActionPerformed(evt);
            }
        });

        q4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q4ActionPerformed(evt);
            }
        });

        q5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q5ActionPerformed(evt);
            }
        });

        q6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q6ActionPerformed(evt);
            }
        });

        lblQ1.setText("Do you consider your blood safe to be transfused to a patient?");

        lblQ2.setText("Have you or your sexual partner ever used recreational/street drugs by nose, mouth or injection needle?");

        lblQ3.setText("Had a tattoo, body piercing, ear piercing or permanent make-up applied?");

        lblQ4.setText("Taken antiretroviral (ARV's) medication, including Truvada?");

        lblQ5.setText("Had Raatib, ritual scarring, ritual piercing, ritual circumcision, blood sharing or been stabbed?");

        lblQ6.setText("Have you or your sexual partner had a needle stick or skin penetrating injury; or  had skin, eye or mouth contact with another person's blood?");

        jLabel3.setText("In the past 6 months have you:");

        jLabel4.setText("For Health Care Workers and their partners only:");

        jLabel5.setText("In the past 6 months:");

        javax.swing.GroupLayout pnlQ1Layout = new javax.swing.GroupLayout(pnlQ1);
        pnlQ1.setLayout(pnlQ1Layout);
        pnlQ1Layout.setHorizontalGroup(
            pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQ1Layout.createSequentialGroup()
                .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(btnBackToMenu))
                    .addGroup(pnlQ1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlQ1Layout.createSequentialGroup()
                                .addGap(144, 144, 144)
                                .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblQ4)
                                    .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lblQ2, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(lblQ1, javax.swing.GroupLayout.Alignment.TRAILING))
                                        .addGroup(pnlQ1Layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addGap(30, 30, 30)
                                            .addComponent(lblQ3))
                                        .addComponent(lblQ5, javax.swing.GroupLayout.Alignment.TRAILING)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(q3)
                                    .addComponent(q2)
                                    .addComponent(q1)
                                    .addComponent(q4)
                                    .addComponent(q5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ1Layout.createSequentialGroup()
                                .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(pnlQ1Layout.createSequentialGroup()
                                        .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(pnlQ1Layout.createSequentialGroup()
                                                .addGap(25, 25, 25)
                                                .addComponent(jLabel5))
                                            .addComponent(jLabel4))
                                        .addGap(41, 41, 41))
                                    .addComponent(lblQ6))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(q6)
                                .addGap(54, 54, 54)
                                .addComponent(btnNext)))))
                .addContainerGap(146, Short.MAX_VALUE))
        );
        pnlQ1Layout.setVerticalGroup(
            pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(btnBackToMenu)
                .addGap(27, 27, 27)
                .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ1Layout.createSequentialGroup()
                        .addComponent(q1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(q2))
                    .addGroup(pnlQ1Layout.createSequentialGroup()
                        .addComponent(lblQ1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblQ2)))
                .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3))
                    .addGroup(pnlQ1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblQ3)
                            .addComponent(q3))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ5)
                    .addComponent(q4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ4)
                    .addComponent(q5))
                .addGap(44, 44, 44)
                .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlQ1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblQ6)
                            .addComponent(q6))
                        .addGap(16, 16, 16))
                    .addComponent(btnNext, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(139, 139, 139))
        );

        getContentPane().add(pnlQ1);
        pnlQ1.setBounds(0, 0, 1000, 600);

        pnlQ2.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnNext1.setText("Next");
        btnNext1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNext1ActionPerformed(evt);
            }
        });

        btnPrevious1.setText("Previous");
        btnPrevious1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevious1ActionPerformed(evt);
            }
        });

        btnBackToMenu1.setText("Back to Menu");
        btnBackToMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMenu1ActionPerformed(evt);
            }
        });

        q7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q7ActionPerformed(evt);
            }
        });

        q8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q8ActionPerformed(evt);
            }
        });

        q9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q9ActionPerformed(evt);
            }
        });

        lblQ7.setText("Do you have AIDS or are you HIV positive?");

        lblQ8.setText("Have you ever had sexual contact with anyone who has AIDS or is HIV positive?");

        lblQ9.setText("Are you only giving blood for an HIV test?");

        javax.swing.GroupLayout pnlQ2Layout = new javax.swing.GroupLayout(pnlQ2);
        pnlQ2.setLayout(pnlQ2Layout);
        pnlQ2Layout.setHorizontalGroup(
            pnlQ2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQ2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(pnlQ2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ2Layout.createSequentialGroup()
                        .addComponent(btnBackToMenu1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlQ2Layout.createSequentialGroup()
                        .addComponent(btnPrevious1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnNext1)
                        .addGap(88, 88, 88))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ8, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblQ7, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblQ9, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlQ2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q9)
                    .addComponent(q8)
                    .addComponent(q7))
                .addGap(284, 284, 284))
        );
        pnlQ2Layout.setVerticalGroup(
            pnlQ2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(btnBackToMenu1)
                .addGap(68, 68, 68)
                .addGroup(pnlQ2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q7)
                    .addComponent(lblQ7))
                .addGap(18, 18, 18)
                .addGroup(pnlQ2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q8)
                    .addComponent(lblQ8))
                .addGap(18, 18, 18)
                .addGroup(pnlQ2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ9)
                    .addComponent(q9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPrevious1)
                    .addComponent(btnNext1))
                .addGap(120, 120, 120))
        );

        getContentPane().add(pnlQ2);
        pnlQ2.setBounds(0, 0, 1000, 600);

        pnlQ3.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnNext2.setText("Next");
        btnNext2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNext2ActionPerformed(evt);
            }
        });

        btnPrevious2.setText("Previous");
        btnPrevious2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevious2ActionPerformed(evt);
            }
        });

        btnBackToMenu2.setText("Back to Menu");
        btnBackToMenu2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMenu2ActionPerformed(evt);
            }
        });

        q10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q10ActionPerformed(evt);
            }
        });

        q11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q11ActionPerformed(evt);
            }
        });

        q12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q12ActionPerformed(evt);
            }
        });

        q13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q13ActionPerformed(evt);
            }
        });

        q14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q14ActionPerformed(evt);
            }
        });

        q15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q15ActionPerformed(evt);
            }
        });

        q16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q16ActionPerformed(evt);
            }
        });

        q17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q17ActionPerformed(evt);
            }
        });

        lblQ10.setText(" Have you started having sexual contact with a new sexual partner?");

        lblQ11.setText("Have you had sexual contact with more than one person?");

        lblQ12.setText("To the best of your knowledge has your sexual partner had sexual contact with more than one person?");

        lblQ13.setText("Have you had sexual contact with someone whose sexual history you do not know?");

        lblQ14.setText("Have you had sexual contact with anyone who takes money, drugs, or other favours for sex?");

        lblQ15.setText("Have you received money, drugs or other payment for sex?");

        lblQ16.setText("Are you a sex worker?");

        lblQ17.setText("Have you been sexually assaulted?");

        jLabel6.setText("In the past 6 months (with or without a condom):");

        javax.swing.GroupLayout pnlQ3Layout = new javax.swing.GroupLayout(pnlQ3);
        pnlQ3.setLayout(pnlQ3Layout);
        pnlQ3Layout.setHorizontalGroup(
            pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQ3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(btnBackToMenu2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(pnlQ3Layout.createSequentialGroup()
                        .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblQ12, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ11, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ10, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ15, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ14, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ13, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ17, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ16, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q17)
                            .addComponent(q16)
                            .addComponent(q15)
                            .addComponent(q14)
                            .addComponent(q13)
                            .addComponent(q12)
                            .addComponent(q11)
                            .addComponent(q10))))
                .addGap(211, 211, 211))
            .addGroup(pnlQ3Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(btnPrevious2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnNext2)
                .addGap(104, 104, 104))
        );
        pnlQ3Layout.setVerticalGroup(
            pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(btnBackToMenu2)
                .addGap(7, 7, 7)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ3Layout.createSequentialGroup()
                        .addComponent(q10)
                        .addGap(36, 36, 36)
                        .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q12)
                            .addComponent(lblQ12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q13)
                            .addComponent(lblQ13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q14)
                            .addComponent(lblQ14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q15)
                            .addComponent(lblQ15))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q16)
                            .addComponent(lblQ16))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblQ17)
                            .addComponent(q17))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnPrevious2)
                            .addComponent(btnNext2))
                        .addGap(95, 95, 95))
                    .addGroup(pnlQ3Layout.createSequentialGroup()
                        .addComponent(lblQ10)
                        .addGap(18, 18, 18)
                        .addGroup(pnlQ3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q11)
                            .addComponent(lblQ11))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        getContentPane().add(pnlQ3);
        pnlQ3.setBounds(0, 0, 1000, 600);

        pnlQ4.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnNext3.setText("Next");
        btnNext3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNext3ActionPerformed(evt);
            }
        });

        btnPrevious3.setText("Previous");
        btnPrevious3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevious3ActionPerformed(evt);
            }
        });

        btnBackToMenu3.setText("Back to Menu");
        btnBackToMenu3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMenu3ActionPerformed(evt);
            }
        });

        q18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q18ActionPerformed(evt);
            }
        });

        q19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q19ActionPerformed(evt);
            }
        });

        q20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q20ActionPerformed(evt);
            }
        });

        q21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q21ActionPerformed(evt);
            }
        });

        q22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q22ActionPerformed(evt);
            }
        });

        q23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q23ActionPerformed(evt);
            }
        });

        q24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q24ActionPerformed(evt);
            }
        });

        lblQ18.setText("Sky diving, deep-sea diving or mountaneering?");

        lblQ19.setText("Have you been to the dentist?");

        lblQ20.setText("Have you taken any painkillers, anti-inflammatories or aspirin (Ecotrin)?");

        lblQ21.setText("Have you or your sexual partner had any sexually transmitted disease (STD) including genital herpes, syphilis, gonorrhoea (drop) or human papiloma virus?");

        lblQ22.setText("Are you feeling well today?");

        lblQ23.setText("In the past 4 hours have you had something to eat and drink?");

        lblQ24.setText("Driving a public or heavy-duty vehicle, flying an aeroplane, working on scaffolding or using power tools?");

        jLabel7.setText("In the past 6 months:");

        jLabel8.setText("Do you participate in any of the following:");

        jLabel9.setText("In the past 3 days:");

        javax.swing.GroupLayout pnlQ4Layout = new javax.swing.GroupLayout(pnlQ4);
        pnlQ4.setLayout(pnlQ4Layout);
        pnlQ4Layout.setHorizontalGroup(
            pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQ4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(pnlQ4Layout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblQ21)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(q18))
                        .addComponent(jLabel7))
                    .addGroup(pnlQ4Layout.createSequentialGroup()
                        .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ22)
                            .addComponent(lblQ23))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q20)
                            .addComponent(q19)))
                    .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel8)
                        .addGroup(pnlQ4Layout.createSequentialGroup()
                            .addComponent(lblQ24)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(q21)))
                    .addGroup(pnlQ4Layout.createSequentialGroup()
                        .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlQ4Layout.createSequentialGroup()
                                .addGap(194, 194, 194)
                                .addComponent(lblQ19))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel9)
                                .addComponent(lblQ20)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q24)
                            .addComponent(q23)))
                    .addGroup(pnlQ4Layout.createSequentialGroup()
                        .addComponent(lblQ18)
                        .addGap(18, 18, 18)
                        .addComponent(q22)))
                .addContainerGap(219, Short.MAX_VALUE))
            .addGroup(pnlQ4Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(btnPrevious3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnNext3)
                .addGap(101, 101, 101))
            .addGroup(pnlQ4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnBackToMenu3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlQ4Layout.setVerticalGroup(
            pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(btnBackToMenu3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ21)
                    .addComponent(q18))
                .addGap(27, 27, 27)
                .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q19)
                    .addComponent(lblQ22))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ23)
                    .addComponent(q20))
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ24)
                    .addComponent(q21))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(q22)
                    .addComponent(lblQ18))
                .addGap(3, 3, 3)
                .addComponent(jLabel9)
                .addGap(10, 10, 10)
                .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q23)
                    .addComponent(lblQ19))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q24)
                    .addComponent(lblQ20))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNext3)
                    .addComponent(btnPrevious3))
                .addGap(60, 60, 60))
        );

        getContentPane().add(pnlQ4);
        pnlQ4.setBounds(0, 0, 1000, 600);

        pnlQ5.setNextFocusableComponent(this);
        pnlQ5.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnNext4.setText("Next");
        btnNext4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNext4ActionPerformed(evt);
            }
        });

        btnPrevious4.setText("Previous");
        btnPrevious4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevious4ActionPerformed(evt);
            }
        });

        btnBackToMenu4.setText("Back to Menu");
        btnBackToMenu4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMenu4ActionPerformed(evt);
            }
        });

        q25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q25ActionPerformed(evt);
            }
        });

        q26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q26ActionPerformed(evt);
            }
        });

        q27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q27ActionPerformed(evt);
            }
        });

        q28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q28ActionPerformed(evt);
            }
        });

        q29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q29ActionPerformed(evt);
            }
        });

        q30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q30ActionPerformed(evt);
            }
        });

        q31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q31ActionPerformed(evt);
            }
        });

        q32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q32ActionPerformed(evt);
            }
        });

        lblQ25.setText("Have you or your sexual partner had a blood transfusion or received blood products or clotting factors?");

        lblQ26.setText("Have you had acupuncture, botox or dry-needling?");

        lblQ27.setText("Have you had a vaccination or immunization (inoculation)?");

        lblQ28.setText("Have you had a cold, flu, sore throat, fever, infection or allergies?");

        lblQ29.setText("Have you experienced diarrhoea or vomiting?");

        lblQ30.setText("Have you taken Androcur, Proscar, Propecia, Roaccutane, Warfarin or Dabigtran Etexilate (Pradaxa)?");

        lblQ31.setText("Have you taken any medication (including traditional medication), injections or tablets?");

        lblQ32.setText("Have you taken part in a drug trial, vaccine trial, or clinical research?");

        jLabel10.setText("In the past 7 days:");

        jLabel11.setText("In the past 30 days:");

        jLabel12.setText("In the past 3 months:");

        jLabel13.setText("In the past 6 months:");

        javax.swing.GroupLayout pnlQ5Layout = new javax.swing.GroupLayout(pnlQ5);
        pnlQ5.setLayout(pnlQ5Layout);
        pnlQ5Layout.setHorizontalGroup(
            pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ5Layout.createSequentialGroup()
                .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlQ5Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(btnBackToMenu4)
                        .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlQ5Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 290, Short.MAX_VALUE)
                                .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblQ28)
                                    .addComponent(lblQ30)))
                            .addGroup(pnlQ5Layout.createSequentialGroup()
                                .addGap(116, 116, 116)
                                .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel13)
                                    .addGroup(pnlQ5Layout.createSequentialGroup()
                                        .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel10)
                                            .addComponent(jLabel11))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lblQ29)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q25)
                            .addComponent(q26)
                            .addComponent(q27)
                            .addComponent(q29)))
                    .addGroup(pnlQ5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblQ25, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ31, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ26, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ27, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ32, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q28)
                            .addComponent(q30)
                            .addComponent(q31)
                            .addComponent(q32)))
                    .addGroup(pnlQ5Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(btnPrevious4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnNext4)))
                .addGap(77, 77, 77))
        );
        pnlQ5Layout.setVerticalGroup(
            pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQ5Layout.createSequentialGroup()
                .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ5Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBackToMenu4)
                            .addComponent(jLabel10))
                        .addGap(105, 105, 105)
                        .addComponent(jLabel12))
                    .addGroup(pnlQ5Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlQ5Layout.createSequentialGroup()
                                .addComponent(q25)
                                .addGap(28, 28, 28)
                                .addComponent(q26)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(q27))
                            .addGroup(pnlQ5Layout.createSequentialGroup()
                                .addComponent(lblQ28)
                                .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnlQ5Layout.createSequentialGroup()
                                        .addGap(35, 35, 35)
                                        .addComponent(lblQ29)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblQ30))
                                    .addGroup(pnlQ5Layout.createSequentialGroup()
                                        .addGap(24, 24, 24)
                                        .addComponent(jLabel11)))))))
                .addGap(8, 8, 8)
                .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ31)
                    .addComponent(q28))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q29)
                    .addComponent(lblQ25))
                .addGap(4, 4, 4)
                .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ5Layout.createSequentialGroup()
                        .addComponent(lblQ26)
                        .addGap(7, 7, 7)
                        .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblQ27)
                            .addComponent(q31)))
                    .addComponent(q32))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ5Layout.createSequentialGroup()
                        .addComponent(lblQ32)
                        .addGap(84, 84, 84)
                        .addGroup(pnlQ5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnNext4)
                            .addComponent(btnPrevious4)))
                    .addComponent(q30))
                .addContainerGap(187, Short.MAX_VALUE))
        );

        getContentPane().add(pnlQ5);
        pnlQ5.setBounds(0, 0, 1000, 600);

        pnlQ6.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnNext5.setText("Next");
        btnNext5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNext5ActionPerformed(evt);
            }
        });

        btnPrevious5.setText("Previous");
        btnPrevious5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevious5ActionPerformed(evt);
            }
        });

        btnBackToMenu5.setText("Back to Menu");
        btnBackToMenu5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMenu5ActionPerformed(evt);
            }
        });

        q33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q33ActionPerformed(evt);
            }
        });

        q34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q34ActionPerformed(evt);
            }
        });

        q35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q35ActionPerformed(evt);
            }
        });

        q36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q36ActionPerformed(evt);
            }
        });

        q37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q37ActionPerformed(evt);
            }
        });

        q38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q38ActionPerformed(evt);
            }
        });

        q39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q39ActionPerformed(evt);
            }
        });

        q40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q40ActionPerformed(evt);
            }
        });

        lblQ33.setText("Heart, lung, circulatory problems or a bleeding disorder?");

        lblQ34.setText("Epilepsy, convulsions or strokes?");

        lblQ35.setText("Cancer, skin cancer or leukaemia?");

        lblQ36.setText("Have you had a surgical procedure or been admitted to hospital?");

        lblQ37.setText("Are you scheduled to have surgery in the next 6 weeks?");

        lblQ38.setText("Have you taken (Neo) Tigason for skin problems?");

        lblQ39.setText("High blood pressure?");

        lblQ40.setText("Diabetes, asthma, TB or kidney disease?");

        jLabel14.setText("In the past 6 months:");

        jLabel15.setText("In the past 2 years:");

        jLabel16.setText("Have you ever had:");

        javax.swing.GroupLayout pnlQ6Layout = new javax.swing.GroupLayout(pnlQ6);
        pnlQ6.setLayout(pnlQ6Layout);
        pnlQ6Layout.setHorizontalGroup(
            pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQ6Layout.createSequentialGroup()
                .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlQ6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ39)
                            .addComponent(lblQ33)
                            .addComponent(lblQ35)
                            .addComponent(lblQ34)
                            .addComponent(lblQ40))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q40)
                            .addComponent(q39)
                            .addComponent(q38)
                            .addComponent(q37)
                            .addComponent(q36)))
                    .addGroup(pnlQ6Layout.createSequentialGroup()
                        .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlQ6Layout.createSequentialGroup()
                                .addGap(396, 396, 396)
                                .addComponent(lblQ36)
                                .addGap(6, 6, 6))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ6Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblQ37, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblQ38, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q33)
                            .addComponent(q34)
                            .addComponent(q35))))
                .addGap(0, 267, Short.MAX_VALUE))
            .addGroup(pnlQ6Layout.createSequentialGroup()
                .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ6Layout.createSequentialGroup()
                        .addGap(316, 316, 316)
                        .addComponent(jLabel14))
                    .addGroup(pnlQ6Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnPrevious5)
                            .addComponent(btnBackToMenu5))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ6Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addGap(333, 333, 333))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ6Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addGap(344, 344, 344))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ6Layout.createSequentialGroup()
                        .addComponent(btnNext5)
                        .addGap(35, 35, 35))))
        );
        pnlQ6Layout.setVerticalGroup(
            pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnBackToMenu5)
                .addGap(1, 1, 1)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ6Layout.createSequentialGroup()
                        .addComponent(lblQ36)
                        .addGap(46, 46, 46)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q35)
                            .addComponent(lblQ38)))
                    .addGroup(pnlQ6Layout.createSequentialGroup()
                        .addComponent(q33)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblQ37)
                            .addComponent(q34, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel16)
                .addGap(18, 18, 18)
                .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q36)
                    .addComponent(lblQ39))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q37)
                    .addComponent(lblQ33))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q38)
                    .addComponent(lblQ34))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q39)
                    .addComponent(lblQ35))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ40)
                    .addComponent(q40))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNext5)
                    .addComponent(btnPrevious5))
                .addGap(94, 94, 94))
        );

        getContentPane().add(pnlQ6);
        pnlQ6.setBounds(0, 0, 1000, 600);

        pnlQ7.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnNext6.setText("Next");
        btnNext6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNext6ActionPerformed(evt);
            }
        });

        btnPrevious6.setText("Previous");
        btnPrevious6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevious6ActionPerformed(evt);
            }
        });

        btnBackToMenu6.setText("Back to Menu");
        btnBackToMenu6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMenu6ActionPerformed(evt);
            }
        });

        q41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q41ActionPerformed(evt);
            }
        });

        q42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q42ActionPerformed(evt);
            }
        });

        q43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q43ActionPerformed(evt);
            }
        });

        q44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q44ActionPerformed(evt);
            }
        });

        q45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q45ActionPerformed(evt);
            }
        });

        q46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q46ActionPerformed(evt);
            }
        });

        q47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q47ActionPerformed(evt);
            }
        });

        q48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q48ActionPerformed(evt);
            }
        });

        lblQ41.setText("Have you had malaria in the past 3 years?");

        lblQ42.setText("Did you grow up in a malaria prevalent area/country?");

        lblQ43.setText("If \"yes\", have you been in any malaria area in the past 3 years?");

        lblQ44.setText("Has your doctor ever advised you to donate blood for medical reasons (high iron, 'thick blood', polycythaemia or haemochromatosis)?");

        lblQ45.setText("Have you ever had yellow jaundice, hepatitis, liver disease or a positive test for hepatitis?");

        lblQ46.setText("In the past 6 months have you been in contact or lived with anyone who has hepatitis (jaundice)?");

        lblQ47.setText("Have you been in a malaria area in the past 3 months?");

        lblQ48.setText("Have you or your sexual partner travelled outside South Africa in the past 3 months?");

        jLabel17.setText("HEPATITIS:");

        jLabel18.setText("MALARIA:");

        javax.swing.GroupLayout pnlQ7Layout = new javax.swing.GroupLayout(pnlQ7);
        pnlQ7.setLayout(pnlQ7Layout);
        pnlQ7Layout.setHorizontalGroup(
            pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQ7Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ7Layout.createSequentialGroup()
                        .addComponent(btnBackToMenu6)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlQ7Layout.createSequentialGroup()
                        .addComponent(btnPrevious6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnNext6)
                        .addGap(68, 68, 68))))
            .addGroup(pnlQ7Layout.createSequentialGroup()
                .addGap(254, 254, 254)
                .addComponent(jLabel17)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ7Layout.createSequentialGroup()
                        .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ44)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlQ7Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jLabel18)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(q41))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ7Layout.createSequentialGroup()
                        .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ46)
                            .addComponent(lblQ45)
                            .addComponent(lblQ41)
                            .addComponent(lblQ47)
                            .addComponent(lblQ42)
                            .addComponent(lblQ43)
                            .addComponent(lblQ48))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q42)
                            .addComponent(q43)
                            .addComponent(q44)
                            .addComponent(q45)
                            .addComponent(q46)
                            .addComponent(q47)
                            .addComponent(q48))))
                .addGap(92, 92, 92))
        );
        pnlQ7Layout.setVerticalGroup(
            pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ7Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(btnBackToMenu6)
                .addGap(18, 18, 18)
                .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ7Layout.createSequentialGroup()
                        .addComponent(lblQ44)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel17)
                        .addGap(5, 5, 5)
                        .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlQ7Layout.createSequentialGroup()
                                .addComponent(lblQ45)
                                .addGap(18, 18, 18)
                                .addComponent(lblQ46))
                            .addGroup(pnlQ7Layout.createSequentialGroup()
                                .addGap(83, 83, 83)
                                .addComponent(jLabel18))
                            .addGroup(pnlQ7Layout.createSequentialGroup()
                                .addComponent(q42)
                                .addGap(11, 11, 11)
                                .addComponent(q43))))
                    .addComponent(q41))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ7Layout.createSequentialGroup()
                        .addComponent(lblQ41)
                        .addGap(18, 18, 18)
                        .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblQ47)
                            .addComponent(q45))
                        .addGap(18, 18, 18)
                        .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblQ42)
                            .addComponent(q46))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q47)
                            .addComponent(lblQ43)))
                    .addComponent(q44))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ48, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(q48))
                .addGap(75, 75, 75)
                .addGroup(pnlQ7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNext6)
                    .addComponent(btnPrevious6))
                .addGap(77, 77, 77))
        );

        getContentPane().add(pnlQ7);
        pnlQ7.setBounds(0, 0, 1000, 600);

        pnlQ8.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnNext7.setText("Next");
        btnNext7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNext7ActionPerformed(evt);
            }
        });

        btnPrevious7.setText("Previous");
        btnPrevious7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevious7ActionPerformed(evt);
            }
        });

        btnBackToMenu7.setText("Back to Menu");
        btnBackToMenu7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMenu7ActionPerformed(evt);
            }
        });

        q50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q50ActionPerformed(evt);
            }
        });

        q51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q51ActionPerformed(evt);
            }
        });

        q52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q52ActionPerformed(evt);
            }
        });

        q53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q53ActionPerformed(evt);
            }
        });

        q54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q54ActionPerformed(evt);
            }
        });

        lblQ49.setText("Have you ever had neuro surgery, received a dura mater (brain covering) graft or taken pituitary growth hormone?");

        lblQ50.setText("Have you or your sexual partner ever received a tissue, cornea or organ transplant?");

        lblQ51.setText("Were you residing in the United Kingdom for a total period of 12 months or longer between Jan. 1980 and Dec. 1996?");

        lblQ52.setText("Have you ever had any other serious illnesses, severe allergic reactions, tropical diseases or medication not mentioned above?");

        lblQ53.setText("Are you participating in a regular training or athletic programme?");

        lblQ54.setText("Have you ever injected yourself or been injected with illegal steroids (body building drugs)?");

        jLabel19.setText("VARIANT CREUTZFELD-JAKOB DISEASE: (also known as Mad Cow disease)");

        javax.swing.GroupLayout pnlQ8Layout = new javax.swing.GroupLayout(pnlQ8);
        pnlQ8.setLayout(pnlQ8Layout);
        pnlQ8Layout.setHorizontalGroup(
            pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ8Layout.createSequentialGroup()
                .addGap(755, 907, Short.MAX_VALUE)
                .addComponent(btnNext7)
                .addGap(38, 38, 38))
            .addGroup(pnlQ8Layout.createSequentialGroup()
                .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ8Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(btnBackToMenu7))
                    .addGroup(pnlQ8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnPrevious7))
                    .addGroup(pnlQ8Layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(pnlQ8Layout.createSequentialGroup()
                                    .addComponent(jLabel19)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 456, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ8Layout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lblQ50, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(lblQ49, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(lblQ51, javax.swing.GroupLayout.Alignment.TRAILING))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(q49)
                                        .addComponent(q50)
                                        .addComponent(q51))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ8Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(pnlQ8Layout.createSequentialGroup()
                                        .addComponent(lblQ53)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(q53))
                                    .addGroup(pnlQ8Layout.createSequentialGroup()
                                        .addComponent(lblQ54)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(q54))
                                    .addGroup(pnlQ8Layout.createSequentialGroup()
                                        .addComponent(lblQ52)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(q52)))
                                .addGap(5, 5, 5)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlQ8Layout.setVerticalGroup(
            pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQ8Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(btnBackToMenu7)
                .addGap(18, 18, 18)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ49, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(q49))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlQ8Layout.createSequentialGroup()
                        .addComponent(lblQ50)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblQ51, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlQ8Layout.createSequentialGroup()
                        .addComponent(q50)
                        .addGap(4, 4, 4)
                        .addComponent(q51)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q52)
                    .addComponent(lblQ52))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q53)
                    .addComponent(lblQ53, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q54)
                    .addComponent(lblQ54))
                .addGap(92, 92, 92)
                .addGroup(pnlQ8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPrevious7)
                    .addComponent(btnNext7))
                .addGap(165, 165, 165))
        );

        getContentPane().add(pnlQ8);
        pnlQ8.setBounds(0, 0, 1000, 600);

        pnlQ9.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnNext8.setText("Next");
        btnNext8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNext8ActionPerformed(evt);
            }
        });

        btnPrevious8.setText("Previous");
        btnPrevious8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevious8ActionPerformed(evt);
            }
        });

        q55.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q55ActionPerformed(evt);
            }
        });

        q56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q56ActionPerformed(evt);
            }
        });

        q57.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                q57ActionPerformed(evt);
            }
        });

        lblQ55.setText("Are you pregnant or undergoing fertility treatment?");

        lblQ56.setText("In the past 3 months have you had a baby, miscarriage or abortion?");

        lblQ57.setText("Are you breastfeeding?");

        btnBackToMenu9.setText("Back to Menu");
        btnBackToMenu9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMenu9ActionPerformed(evt);
            }
        });

        jLabel20.setText("FOR WOMEN ONLY:");

        javax.swing.GroupLayout pnlQ9Layout = new javax.swing.GroupLayout(pnlQ9);
        pnlQ9.setLayout(pnlQ9Layout);
        pnlQ9Layout.setHorizontalGroup(
            pnlQ9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQ9Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(btnBackToMenu9)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pnlQ9Layout.createSequentialGroup()
                .addGap(294, 294, 294)
                .addGroup(pnlQ9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlQ9Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel20))
                    .addGroup(pnlQ9Layout.createSequentialGroup()
                        .addGroup(pnlQ9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblQ56)
                            .addComponent(lblQ55)
                            .addComponent(lblQ57))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlQ9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(q55)
                            .addComponent(q56)
                            .addComponent(q57))))
                .addGap(0, 352, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnPrevious8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnNext8)
                .addGap(107, 107, 107))
        );
        pnlQ9Layout.setVerticalGroup(
            pnlQ9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQ9Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(btnBackToMenu9)
                .addGap(91, 91, 91)
                .addComponent(jLabel20)
                .addGap(18, 18, 18)
                .addGroup(pnlQ9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ55)
                    .addComponent(q55))
                .addGap(34, 34, 34)
                .addGroup(pnlQ9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQ56)
                    .addComponent(q56))
                .addGap(34, 34, 34)
                .addGroup(pnlQ9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(q57)
                    .addComponent(lblQ57, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlQ9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNext8)
                    .addComponent(btnPrevious8))
                .addGap(111, 111, 111))
        );

        getContentPane().add(pnlQ9);
        pnlQ9.setBounds(0, 0, 1000, 600);

        pnlProcessQuestionnaire.setPreferredSize(new java.awt.Dimension(1000, 600));

        btnBackToMenu8.setText("Back to Menu");
        btnBackToMenu8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMenu8ActionPerformed(evt);
            }
        });

        btnPrevious9.setText("Previous");
        btnPrevious9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevious9ActionPerformed(evt);
            }
        });

        btnProcessQuestionnaire.setText("Process Questionnaire");
        btnProcessQuestionnaire.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProcessQuestionnaireActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlProcessQuestionnaireLayout = new javax.swing.GroupLayout(pnlProcessQuestionnaire);
        pnlProcessQuestionnaire.setLayout(pnlProcessQuestionnaireLayout);
        pnlProcessQuestionnaireLayout.setHorizontalGroup(
            pnlProcessQuestionnaireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlProcessQuestionnaireLayout.createSequentialGroup()
                .addContainerGap(371, Short.MAX_VALUE)
                .addGroup(pnlProcessQuestionnaireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlProcessQuestionnaireLayout.createSequentialGroup()
                        .addComponent(btnPrevious9)
                        .addGap(114, 114, 114)
                        .addComponent(btnBackToMenu8)
                        .addGap(311, 311, 311))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlProcessQuestionnaireLayout.createSequentialGroup()
                        .addComponent(btnProcessQuestionnaire)
                        .addGap(393, 393, 393))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlProcessQuestionnaireLayout.createSequentialGroup()
                        .addComponent(lblProcessQuestionnaire, javax.swing.GroupLayout.PREFERRED_SIZE, 502, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(127, 127, 127))))
        );
        pnlProcessQuestionnaireLayout.setVerticalGroup(
            pnlProcessQuestionnaireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlProcessQuestionnaireLayout.createSequentialGroup()
                .addGap(147, 147, 147)
                .addComponent(lblProcessQuestionnaire, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(btnProcessQuestionnaire)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 219, Short.MAX_VALUE)
                .addGroup(pnlProcessQuestionnaireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBackToMenu8)
                    .addComponent(btnPrevious9))
                .addGap(105, 105, 105))
        );

        getContentPane().add(pnlProcessQuestionnaire);
        pnlProcessQuestionnaire.setBounds(0, 0, 1000, 600);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            @Override
            public void run() 
            {
                new PAT2019UI().setVisible(true);
                
            }
        });
        
        this.dispose();
    }//GEN-LAST:event_btnLogOutActionPerformed

    private void btnCompleteQuestionnaireActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCompleteQuestionnaireActionPerformed
        
        
        long daysSince = toArr.donorAtUsername(username).daysBetween();
        
        if(daysSince > 56)
        {
            pnlCompleteQuestionnaire.setVisible(true);
            pnlDonorMenu.setVisible(false);
        }
        else
        {
            lblQuestionnaireValidation.setText("You have to wait at least " +(56-daysSince) + " days before donating again.");
        }
    }//GEN-LAST:event_btnCompleteQuestionnaireActionPerformed

    private void btnUpdateDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateDetailsActionPerformed
        pnlDonorMenu.setVisible(false);
        pnlUpdateDetails.setVisible(true);
    }//GEN-LAST:event_btnUpdateDetailsActionPerformed

    private void btnHelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHelpActionPerformed
        pnlDonorMenu.setVisible(false);
        pnlHelp.setVisible(true);
        
        txtHelp.setEditable(false);
    }//GEN-LAST:event_btnHelpActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlCompleteQuestionnaire.setVisible(false);
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnBack1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBack1ActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlUpdateDetails.setVisible(false);
    }//GEN-LAST:event_btnBack1ActionPerformed

    private void btnBack2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBack2ActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlHelp.setVisible(false);
    }//GEN-LAST:event_btnBack2ActionPerformed

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        pnlQ1.setVisible(true);
        pnlCompleteQuestionnaire.setVisible(false);
    }//GEN-LAST:event_btnStartActionPerformed

    private void btnBackToMenu8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMenu8ActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlProcessQuestionnaire.setVisible(false);
    }//GEN-LAST:event_btnBackToMenu8ActionPerformed

    private void btnBackToMenu6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMenu6ActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlQ7.setVisible(false);
    }//GEN-LAST:event_btnBackToMenu6ActionPerformed

    private void btnBackToMenu5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMenu5ActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlQ6.setVisible(false);
    }//GEN-LAST:event_btnBackToMenu5ActionPerformed

    private void btnPrevious5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevious5ActionPerformed
        pnlQ5.setVisible(true);
        pnlQ6.setVisible(false);
    }//GEN-LAST:event_btnPrevious5ActionPerformed

    private void btnBackToMenu4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMenu4ActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlQ5.setVisible(false);
    }//GEN-LAST:event_btnBackToMenu4ActionPerformed

    private void btnBackToMenu3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMenu3ActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlQ4.setVisible(false);
    }//GEN-LAST:event_btnBackToMenu3ActionPerformed

    private void btnBackToMenu2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMenu2ActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlQ3.setVisible(false);
    }//GEN-LAST:event_btnBackToMenu2ActionPerformed

    private void btnBackToMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMenu1ActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlQ2.setVisible(false);
    }//GEN-LAST:event_btnBackToMenu1ActionPerformed

    private void btnBackToMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMenuActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlQ1.setVisible(false);
    }//GEN-LAST:event_btnBackToMenuActionPerformed

    private void q2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q2ActionPerformed

    private void q3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q3ActionPerformed

    private void q4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q4ActionPerformed

    private void q5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q5ActionPerformed

    private void q6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q6ActionPerformed

    private void q7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q7ActionPerformed

    private void q8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q8ActionPerformed

    private void q9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q9ActionPerformed

    private void q10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q10ActionPerformed

    private void q11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q11ActionPerformed

    private void q12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q12ActionPerformed

    private void q13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q13ActionPerformed

    private void q14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q14ActionPerformed

    private void q15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q15ActionPerformed

    private void q16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q16ActionPerformed

    private void q17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q17ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q17ActionPerformed

    private void q18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q18ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q18ActionPerformed

    private void q19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q19ActionPerformed

    private void q20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q20ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q20ActionPerformed

    private void q21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q21ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q21ActionPerformed

    private void q22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q22ActionPerformed

    private void q23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q23ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q23ActionPerformed

    private void q24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q24ActionPerformed

    private void q25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q25ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q25ActionPerformed

    private void q26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q26ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q26ActionPerformed

    private void q27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q27ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q27ActionPerformed

    private void q28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q28ActionPerformed

    private void q29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q29ActionPerformed

    private void q30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q30ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q30ActionPerformed

    private void q31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q31ActionPerformed

    private void q32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q32ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q32ActionPerformed

    private void q33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q33ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q33ActionPerformed

    private void q34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q34ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q34ActionPerformed

    private void q35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q35ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q35ActionPerformed

    private void q36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q36ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q36ActionPerformed

    private void q37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q37ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q37ActionPerformed

    private void q38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q38ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q38ActionPerformed

    private void q39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q39ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q39ActionPerformed

    private void q40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q40ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q40ActionPerformed

    private void q41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q41ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q41ActionPerformed

    private void q42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q42ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q42ActionPerformed

    private void q43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q43ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q43ActionPerformed

    private void q44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q44ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q44ActionPerformed

    private void q45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q45ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q45ActionPerformed

    private void q46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q46ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q46ActionPerformed

    private void q47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q47ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q47ActionPerformed

    private void q48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q48ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q48ActionPerformed

    private void q55ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q55ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q55ActionPerformed

    private void q54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q54ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q54ActionPerformed

    private void q53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q53ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q53ActionPerformed

    private void q52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q52ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q52ActionPerformed

    private void q51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q51ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q51ActionPerformed

    private void q50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q50ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q50ActionPerformed

    private void btnBackToMenu7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMenu7ActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlQ8.setVisible(false);
    }//GEN-LAST:event_btnBackToMenu7ActionPerformed

    private void q56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q56ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q56ActionPerformed

    private void q57ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_q57ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_q57ActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        pnlQ2.setVisible(true);
        pnlQ1.setVisible(false);
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnNext1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNext1ActionPerformed
        pnlQ3.setVisible(true);
        pnlQ2.setVisible(false);
    }//GEN-LAST:event_btnNext1ActionPerformed

    private void btnNext2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNext2ActionPerformed
        pnlQ4.setVisible(true);
        pnlQ3.setVisible(false);
    }//GEN-LAST:event_btnNext2ActionPerformed

    private void btnNext3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNext3ActionPerformed
        pnlQ5.setVisible(true);
        pnlQ4.setVisible(false);
    }//GEN-LAST:event_btnNext3ActionPerformed

    private void btnNext4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNext4ActionPerformed
        pnlQ6.setVisible(true);
        pnlQ5.setVisible(false);
    }//GEN-LAST:event_btnNext4ActionPerformed

    private void btnNext5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNext5ActionPerformed
        pnlQ7.setVisible(true);
        pnlQ6.setVisible(false);
    }//GEN-LAST:event_btnNext5ActionPerformed

    private void btnNext6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNext6ActionPerformed
        pnlQ8.setVisible(true);
        pnlQ7.setVisible(false);
    }//GEN-LAST:event_btnNext6ActionPerformed

    private void btnNext7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNext7ActionPerformed
        
        
        if(!(toArr.donorAtUsername(username).getSex()))
        {
            pnlQ9.setVisible(true);
        }
        else
        {
            pnlProcessQuestionnaire.setVisible(true);
        }
        
        pnlQ8.setVisible(false);
    }//GEN-LAST:event_btnNext7ActionPerformed

    private void btnNext8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNext8ActionPerformed
        pnlProcessQuestionnaire.setVisible(true);
        pnlQ9.setVisible(false);
    }//GEN-LAST:event_btnNext8ActionPerformed

    private void btnPrevious1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevious1ActionPerformed
        pnlQ1.setVisible(true);
        pnlQ2.setVisible(false);
    }//GEN-LAST:event_btnPrevious1ActionPerformed

    private void btnPrevious2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevious2ActionPerformed
        pnlQ2.setVisible(true);
        pnlQ3.setVisible(false);
    }//GEN-LAST:event_btnPrevious2ActionPerformed

    private void btnPrevious3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevious3ActionPerformed
        pnlQ3.setVisible(true);
        pnlQ4.setVisible(false);
    }//GEN-LAST:event_btnPrevious3ActionPerformed

    private void btnPrevious4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevious4ActionPerformed
        pnlQ4.setVisible(true);
        pnlQ5.setVisible(false);
    }//GEN-LAST:event_btnPrevious4ActionPerformed

    private void btnPrevious6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevious6ActionPerformed
        pnlQ6.setVisible(true);
        pnlQ7.setVisible(false);
    }//GEN-LAST:event_btnPrevious6ActionPerformed

    private void btnPrevious7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevious7ActionPerformed
        pnlQ7.setVisible(true);
        pnlQ8.setVisible(false);
    }//GEN-LAST:event_btnPrevious7ActionPerformed

    private void btnPrevious8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevious8ActionPerformed
        pnlQ8.setVisible(true);
        pnlQ9.setVisible(false);
    }//GEN-LAST:event_btnPrevious8ActionPerformed

    private void btnBackToMenu9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMenu9ActionPerformed
        pnlDonorMenu.setVisible(true);
        pnlQ9.setVisible(false);
    }//GEN-LAST:event_btnBackToMenu9ActionPerformed

    private void btnPrevious9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevious9ActionPerformed
        if(!(toArr.donorAtUsername(username).getSex()))
        {
            pnlQ9.setVisible(true);
        }
        else
        {
            pnlQ8.setVisible(true);
        }
        
        pnlProcessQuestionnaire.setVisible(false);
    }//GEN-LAST:event_btnPrevious9ActionPerformed

    private void btnProcessQuestionnaireActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProcessQuestionnaireActionPerformed
        
        
        Questionnaire questionnaire = new Questionnaire(q1.isSelected(), q2.isSelected(), q3.isSelected(), q4.isSelected(), q5.isSelected(), 
                            q6.isSelected(), q7.isSelected(), q8.isSelected(), q9.isSelected(), q10.isSelected(), q11.isSelected(), q12.isSelected(), 
                            q13.isSelected(), q14.isSelected(), q15.isSelected(), q16.isSelected(), q17.isSelected(), q18.isSelected(), q19.isSelected(), 
                            q20.isSelected(), q21.isSelected(), q22.isSelected(), q23.isSelected(), q24.isSelected(), q25.isSelected(), q26.isSelected(), 
                            q27.isSelected(), q28.isSelected(), q29.isSelected(), q30.isSelected(), q31.isSelected(), q32.isSelected(), q33.isSelected(), 
                            q34.isSelected(), q35.isSelected(), q36.isSelected(), q37.isSelected(), q38.isSelected(), q39.isSelected(), q40.isSelected(), 
                            q41.isSelected(), q42.isSelected(), q43.isSelected(), q44.isSelected(), q45.isSelected(), q46.isSelected(), q47.isSelected(), 
                            q48.isSelected(), q49.isSelected(), q50.isSelected(), q51.isSelected(), q52.isSelected(), q53.isSelected(), q54.isSelected(), 
                            q55.isSelected(), q56.isSelected(), q57.isSelected());
        
        questionnaire.toTable(username);
        
        int code = questionnaire.getID(username);
        
        if(q3.isSelected() || q4.isSelected() || q5.isSelected() || q6.isSelected() ||
                q7.isSelected() || q8.isSelected() || q9.isSelected() || q10.isSelected() || q11.isSelected() || q12.isSelected() || 
                q13.isSelected() || q14.isSelected() || q15.isSelected() || q16.isSelected() || q17.isSelected() || q18.isSelected())
        {
            lblProcessQuestionnaire.setText("You are currently not able to donate blood.");
        }
        else
        {
            lblProcessQuestionnaire.setText("Your code is " + code + ". Please give this to the nurse on duty.");
        }
        
    }//GEN-LAST:event_btnProcessQuestionnaireActionPerformed

    private void txtWeightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtWeightActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtWeightActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        boolean weight, surname;
        
        weight = false;
        surname = false;
        
        lblWeightValidation.setText("");
        lblSurnameValidation.setText("");
        lblUpdateDetails.setText("");
        
        if(txtWeight.getText().equalsIgnoreCase(""))
        {
            lblWeightValidation.setText("Please enter your weight.");
        }
        else
        {
            for(int i = 0; i < txtWeight.getText().length(); i++)
            {
               if(Character.isDigit(txtWeight.getText().charAt(i)) || txtWeight.getText().charAt(i) == ',' || txtWeight.getText().charAt(i) == '.')
                {
                    if(Double.parseDouble(txtWeight.getText()) >= 50)
                    {
                        weight = true;
                    }
                    else
                    {
                        lblWeightValidation.setText("You must weigh 50kg or more.");
                    }
                }
                else
                {
                    lblWeightValidation.setText("Please enter a numerical value.");
                } 
            }
        }
        
        if(txtSurname.getText().equalsIgnoreCase(""))
        {
            lblSurnameValidation.setText("Please enter your surname.");
        }
        else
        {
            surname = true;
        }
        
        if(weight)
        {
            toArr.donorAtUsername(username).setWeight(Double.parseDouble(txtWeight.getText()));
            lblUpdateDetails.setText("Updated.");
        }
        
        if(surname)
        {
            toArr.donorAtUsername(username).setSurname(txtSurname.getText());
            lblUpdateDetails.setText("Updated.");
        }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnLogOut1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOut1ActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable()
            {
                public void run()
                {
                    new PAT2019UI().setVisible(true);
                }
            });

            this.dispose();
    }//GEN-LAST:event_btnLogOut1ActionPerformed

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnBack1;
    private javax.swing.JButton btnBack2;
    private javax.swing.JButton btnBackToMenu;
    private javax.swing.JButton btnBackToMenu1;
    private javax.swing.JButton btnBackToMenu2;
    private javax.swing.JButton btnBackToMenu3;
    private javax.swing.JButton btnBackToMenu4;
    private javax.swing.JButton btnBackToMenu5;
    private javax.swing.JButton btnBackToMenu6;
    private javax.swing.JButton btnBackToMenu7;
    private javax.swing.JButton btnBackToMenu8;
    private javax.swing.JButton btnBackToMenu9;
    private javax.swing.JButton btnCompleteQuestionnaire;
    private javax.swing.JButton btnHelp;
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnLogOut1;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnNext1;
    private javax.swing.JButton btnNext2;
    private javax.swing.JButton btnNext3;
    private javax.swing.JButton btnNext4;
    private javax.swing.JButton btnNext5;
    private javax.swing.JButton btnNext6;
    private javax.swing.JButton btnNext7;
    private javax.swing.JButton btnNext8;
    private javax.swing.JButton btnPrevious1;
    private javax.swing.JButton btnPrevious2;
    private javax.swing.JButton btnPrevious3;
    private javax.swing.JButton btnPrevious4;
    private javax.swing.JButton btnPrevious5;
    private javax.swing.JButton btnPrevious6;
    private javax.swing.JButton btnPrevious7;
    private javax.swing.JButton btnPrevious8;
    private javax.swing.JButton btnPrevious9;
    private javax.swing.JButton btnProcessQuestionnaire;
    private javax.swing.JButton btnStart;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btnUpdateDetails;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblDonorMenuValidation;
    private javax.swing.JLabel lblKG;
    private javax.swing.JLabel lblProcessQuestionnaire;
    private javax.swing.JLabel lblQ1;
    private javax.swing.JLabel lblQ10;
    private javax.swing.JLabel lblQ11;
    private javax.swing.JLabel lblQ12;
    private javax.swing.JLabel lblQ13;
    private javax.swing.JLabel lblQ14;
    private javax.swing.JLabel lblQ15;
    private javax.swing.JLabel lblQ16;
    private javax.swing.JLabel lblQ17;
    private javax.swing.JLabel lblQ18;
    private javax.swing.JLabel lblQ19;
    private javax.swing.JLabel lblQ2;
    private javax.swing.JLabel lblQ20;
    private javax.swing.JLabel lblQ21;
    private javax.swing.JLabel lblQ22;
    private javax.swing.JLabel lblQ23;
    private javax.swing.JLabel lblQ24;
    private javax.swing.JLabel lblQ25;
    private javax.swing.JLabel lblQ26;
    private javax.swing.JLabel lblQ27;
    private javax.swing.JLabel lblQ28;
    private javax.swing.JLabel lblQ29;
    private javax.swing.JLabel lblQ3;
    private javax.swing.JLabel lblQ30;
    private javax.swing.JLabel lblQ31;
    private javax.swing.JLabel lblQ32;
    private javax.swing.JLabel lblQ33;
    private javax.swing.JLabel lblQ34;
    private javax.swing.JLabel lblQ35;
    private javax.swing.JLabel lblQ36;
    private javax.swing.JLabel lblQ37;
    private javax.swing.JLabel lblQ38;
    private javax.swing.JLabel lblQ39;
    private javax.swing.JLabel lblQ4;
    private javax.swing.JLabel lblQ40;
    private javax.swing.JLabel lblQ41;
    private javax.swing.JLabel lblQ42;
    private javax.swing.JLabel lblQ43;
    private javax.swing.JLabel lblQ44;
    private javax.swing.JLabel lblQ45;
    private javax.swing.JLabel lblQ46;
    private javax.swing.JLabel lblQ47;
    private javax.swing.JLabel lblQ48;
    private javax.swing.JLabel lblQ49;
    private javax.swing.JLabel lblQ5;
    private javax.swing.JLabel lblQ50;
    private javax.swing.JLabel lblQ51;
    private javax.swing.JLabel lblQ52;
    private javax.swing.JLabel lblQ53;
    private javax.swing.JLabel lblQ54;
    private javax.swing.JLabel lblQ55;
    private javax.swing.JLabel lblQ56;
    private javax.swing.JLabel lblQ57;
    private javax.swing.JLabel lblQ6;
    private javax.swing.JLabel lblQ7;
    private javax.swing.JLabel lblQ8;
    private javax.swing.JLabel lblQ9;
    private javax.swing.JLabel lblQuestionnaireValidation;
    private javax.swing.JLabel lblSetSurname;
    private javax.swing.JLabel lblSetWeight;
    private javax.swing.JLabel lblSurnameValidation;
    private javax.swing.JLabel lblUpdateDetails;
    private javax.swing.JLabel lblWeightValidation;
    private javax.swing.JPanel pnlCompleteQuestionnaire;
    private javax.swing.JPanel pnlDonorMenu;
    private javax.swing.JPanel pnlHelp;
    private javax.swing.JPanel pnlProcessQuestionnaire;
    private javax.swing.JPanel pnlQ1;
    private javax.swing.JPanel pnlQ2;
    private javax.swing.JPanel pnlQ3;
    private javax.swing.JPanel pnlQ4;
    private javax.swing.JPanel pnlQ5;
    private javax.swing.JPanel pnlQ6;
    private javax.swing.JPanel pnlQ7;
    private javax.swing.JPanel pnlQ8;
    private javax.swing.JPanel pnlQ9;
    private javax.swing.JPanel pnlUpdateDetails;
    private javax.swing.JCheckBox q1;
    private javax.swing.JCheckBox q10;
    private javax.swing.JCheckBox q11;
    private javax.swing.JCheckBox q12;
    private javax.swing.JCheckBox q13;
    private javax.swing.JCheckBox q14;
    private javax.swing.JCheckBox q15;
    private javax.swing.JCheckBox q16;
    private javax.swing.JCheckBox q17;
    private javax.swing.JCheckBox q18;
    private javax.swing.JCheckBox q19;
    private javax.swing.JCheckBox q2;
    private javax.swing.JCheckBox q20;
    private javax.swing.JCheckBox q21;
    private javax.swing.JCheckBox q22;
    private javax.swing.JCheckBox q23;
    private javax.swing.JCheckBox q24;
    private javax.swing.JCheckBox q25;
    private javax.swing.JCheckBox q26;
    private javax.swing.JCheckBox q27;
    private javax.swing.JCheckBox q28;
    private javax.swing.JCheckBox q29;
    private javax.swing.JCheckBox q3;
    private javax.swing.JCheckBox q30;
    private javax.swing.JCheckBox q31;
    private javax.swing.JCheckBox q32;
    private javax.swing.JCheckBox q33;
    private javax.swing.JCheckBox q34;
    private javax.swing.JCheckBox q35;
    private javax.swing.JCheckBox q36;
    private javax.swing.JCheckBox q37;
    private javax.swing.JCheckBox q38;
    private javax.swing.JCheckBox q39;
    private javax.swing.JCheckBox q4;
    private javax.swing.JCheckBox q40;
    private javax.swing.JCheckBox q41;
    private javax.swing.JCheckBox q42;
    private javax.swing.JCheckBox q43;
    private javax.swing.JCheckBox q44;
    private javax.swing.JCheckBox q45;
    private javax.swing.JCheckBox q46;
    private javax.swing.JCheckBox q47;
    private javax.swing.JCheckBox q48;
    private javax.swing.JCheckBox q49;
    private javax.swing.JCheckBox q5;
    private javax.swing.JCheckBox q50;
    private javax.swing.JCheckBox q51;
    private javax.swing.JCheckBox q52;
    private javax.swing.JCheckBox q53;
    private javax.swing.JCheckBox q54;
    private javax.swing.JCheckBox q55;
    private javax.swing.JCheckBox q56;
    private javax.swing.JCheckBox q57;
    private javax.swing.JCheckBox q6;
    private javax.swing.JCheckBox q7;
    private javax.swing.JCheckBox q8;
    private javax.swing.JCheckBox q9;
    private javax.swing.JTextArea txtHelp;
    private javax.swing.JTextField txtSurname;
    private javax.swing.JTextField txtWeight;
    // End of variables declaration//GEN-END:variables
}
