package hill;

import java.sql.Date;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Calendar;
import java.sql.PreparedStatement;

public class Donor extends User
{
    private Connection connection = null;
    private Statement statement = null;
    private ResultSet donor = null;
    private PreparedStatement donors = null;
            
    private String name;
    private String surname;
    private String id;
    private boolean sex;
    private Date dob;
    private Date lastDonation;
    private double weight;
    private Donation[] arrDonations = new Donation[100];
    private int count = 0;
    
    private final String msAccDB = "dbWCBS.accdb";
    private final String dbURL = "jdbc:ucanaccess://" + msAccDB; 
    
    Donor(String a, String b, String c, boolean d, Date e, double f, String g, String h)//Instantiates a Donor object with the personal details accepted as its values.
    {
        super(g,h);
        name = a;
        surname = b;
        id = c;
        sex = d;
        dob = e;
        weight = f;
        
        lastDonation = null;
    }
           
    public String getUsername()//Returns the string value of the username.
    {
        return username;
    }
    
    public boolean getSex()//Returns true if male, false if female.
    {
        return sex;
    }
            
    public void donationsToArr()//Retrieves all the donations corresponding to the donor from tblDonations and stores them in an array.
    {
        try 
        {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        }
        catch(ClassNotFoundException cnfex) 
        {
 
            System.out.println("Problem in loading or registering MS Access JDBC driver");
            cnfex.printStackTrace();
        }
        try 
        {
            connection = DriverManager.getConnection(dbURL); 

            statement = connection.createStatement();
            
            donor = 
                    statement.executeQuery("SELECT [Donation Date] FROM tblDonations, tblQuestionnaire "
                            + "WHERE tblDonations.QuestionnaireID = tblQuestionnaire.QuestionnaireID AND "
                            + "tblQuestionnaire.DonorID = (SELECT DonorID FROM tblDonors WHERE Username = \"" 
                            + getUsername() + "\")");
                        
            while(donor.next())
            {
                arrDonations[count] = new Donation(donor.getDate(1));
                
                count++;
            }
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
        }
    }
    
    public Date getLastDonation()//Returns the date of the donor’s last donation.
    {
        if(count > 0)
        {
            lastDonation = arrDonations[count-1].getDonationDate();
        }
        else
        {
            lastDonation = dob;
        }
        
        return lastDonation;
    }
    
    public int daysBetween()//Returns the number of days since the donor’s last donation and the current day.
    {
              
        int daysdiff = 0;
        long diff = Calendar.getInstance().getTime().getTime() - getLastDonation().getTime();
        long diffDays = diff / (24 * 60 * 60 * 1000) + 1;
        daysdiff = (int) diffDays;
        
        return daysdiff;
    }
    
    public void toTable()//Inserts the object’s values into tblDonors as a new record.
    {
        String sqlStatement;
                        
        try 
        {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        }
        catch(ClassNotFoundException cnfex) 
        {
 
            System.out.println("Problem in loading or registering MS Access JDBC driver");
            cnfex.printStackTrace();
        }
        try 
        {
            
            connection = DriverManager.getConnection(dbURL); 

            statement = connection.createStatement();
            
            sqlStatement = "INSERT INTO tblDonors([First Name], Surname, Sex, [ID Number], [Date of Birth], Weight, Username, Password)"
                        + " VALUES(\"" + name + "\", \"" + surname + "\", " + sex + ", \"" + id
                        + "\", #" + dob + "#, " + weight + ", \"" + username + "\", \"" + password + "\")";
                
            donors = connection.prepareStatement(sqlStatement);
            donors.executeUpdate();
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
        }
    }
    
    public void setSurname(String newSurname)//Accepts a string as the new surname value which is also updated in tblDonors.
    {
        String sqlStatement = "UPDATE tblDonors SET Surname = \"" + newSurname + "\" WHERE Username = \"" + username + "\"";
        
        try 
        {
            donors = connection.prepareStatement(sqlStatement);
            donors.executeUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Donor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        surname = newSurname;
    }
    
    public void setWeight(double newWeight)//Accepts a double as the new weight value which is also updated in tblDonors.
    {
        String sqlStatement = "UPDATE tblDonors SET Weight = \"" + newWeight + "\" WHERE Username = \"" + username + "\"";
        
        try 
        {
            donors = connection.prepareStatement(sqlStatement);
            donors.executeUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Donor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        weight = newWeight;
    }
    
    public String getName()//Returns the donor’s name.
    {
        return name;
    }
    
    public String getSurname()//Returns the donor’s surname.
    {
        return surname;
    }
    
    public Date getDOB()//Returns the donor’s date of birth.
    {       
        return dob;
    }
}
