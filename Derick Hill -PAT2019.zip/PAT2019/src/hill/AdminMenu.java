package hill;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class AdminMenu extends javax.swing.JFrame {

    String username;
    
    UsersToArray toArr = new UsersToArray();
    
    public AdminMenu(String user) 
    {
        username = user;
        
        initComponents();
        
        pnlAdminMenu.setVisible(true);
        pnlUpdateDetails.setVisible(false);
        pnlAddNurse.setVisible(false);
        pnlHelp.setVisible(false);
        
        txtHelp.setEditable(false);        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlAddNurse = new javax.swing.JPanel();
        btnBack = new javax.swing.JButton();
        txtSetUsername = new javax.swing.JTextField();
        lblUsernameValidation = new javax.swing.JLabel();
        lblSetUsername = new javax.swing.JLabel();
        lblConfirmPassword = new javax.swing.JLabel();
        txtSetPassword = new javax.swing.JPasswordField();
        txtConfirmPassword = new javax.swing.JPasswordField();
        lblPasswordValidation = new javax.swing.JLabel();
        lblConfirmPasswordValidation = new javax.swing.JLabel();
        lblSetPassword = new javax.swing.JLabel();
        btnAddNurse1 = new javax.swing.JButton();
        lblNurseAdded = new javax.swing.JLabel();
        pnlUpdateDetails = new javax.swing.JPanel();
        btnBack1 = new javax.swing.JButton();
        lblAdminUsernameValidation = new javax.swing.JLabel();
        lblAdminUsername = new javax.swing.JLabel();
        lblAdminPassword = new javax.swing.JLabel();
        btnUpdate = new javax.swing.JButton();
        txtAdminUsername = new javax.swing.JTextField();
        lblUpdateDetails = new javax.swing.JLabel();
        lblAdminConfirmPassword = new javax.swing.JLabel();
        txtAdminPassword = new javax.swing.JPasswordField();
        txtAdminConfirmPassword = new javax.swing.JPasswordField();
        lblAdminConfirmPasswordValidation = new javax.swing.JLabel();
        lblAdminPasswordValidation = new javax.swing.JLabel();
        pnlHelp = new javax.swing.JPanel();
        btnBack2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtHelp = new javax.swing.JTextArea();
        pnlAdminMenu = new javax.swing.JPanel();
        btnAddNurse = new javax.swing.JButton();
        btnLogOut = new javax.swing.JButton();
        btnUpdateDetails = new javax.swing.JButton();
        btnHelp = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1000, 600));
        getContentPane().setLayout(null);

        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        txtSetUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSetUsernameActionPerformed(evt);
            }
        });

        lblSetUsername.setText("Username:");

        lblConfirmPassword.setText("Confirm password:");

        txtSetPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSetPasswordActionPerformed(evt);
            }
        });

        lblSetPassword.setText("Password:");

        btnAddNurse1.setText("Add Nurse");
        btnAddNurse1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddNurse1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlAddNurseLayout = new javax.swing.GroupLayout(pnlAddNurse);
        pnlAddNurse.setLayout(pnlAddNurseLayout);
        pnlAddNurseLayout.setHorizontalGroup(
            pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAddNurseLayout.createSequentialGroup()
                .addContainerGap(197, Short.MAX_VALUE)
                .addGroup(pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAddNurseLayout.createSequentialGroup()
                        .addComponent(lblSetUsername)
                        .addGap(18, 18, 18)
                        .addComponent(txtSetUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblUsernameValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAddNurseLayout.createSequentialGroup()
                        .addGroup(pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblConfirmPassword)
                            .addComponent(lblSetPassword))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtSetPassword)
                            .addComponent(txtConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblPasswordValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblConfirmPasswordValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(121, 121, 121))))
            .addGroup(pnlAddNurseLayout.createSequentialGroup()
                .addGroup(pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlAddNurseLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(btnBack))
                    .addGroup(pnlAddNurseLayout.createSequentialGroup()
                        .addGap(347, 347, 347)
                        .addComponent(btnAddNurse1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pnlAddNurseLayout.createSequentialGroup()
                .addGap(279, 279, 279)
                .addComponent(lblNurseAdded, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pnlAddNurseLayout.setVerticalGroup(
            pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAddNurseLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(btnBack)
                .addGap(49, 49, 49)
                .addGroup(pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblSetUsername)
                        .addComponent(txtSetUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblUsernameValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(pnlAddNurseLayout.createSequentialGroup()
                        .addGroup(pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtSetPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblSetPassword))
                        .addGap(18, 18, 18)
                        .addGroup(pnlAddNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblConfirmPassword)
                            .addComponent(txtConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlAddNurseLayout.createSequentialGroup()
                        .addComponent(lblPasswordValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblConfirmPasswordValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblNurseAdded, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAddNurse1)
                .addContainerGap(132, Short.MAX_VALUE))
        );

        getContentPane().add(pnlAddNurse);
        pnlAddNurse.setBounds(0, 0, 870, 470);

        btnBack1.setText("Back");
        btnBack1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBack1ActionPerformed(evt);
            }
        });

        lblAdminUsername.setText("Set username to:");

        lblAdminPassword.setText("Set password to:");

        btnUpdate.setText("Update details");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        txtAdminUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAdminUsernameActionPerformed(evt);
            }
        });

        lblAdminConfirmPassword.setText("Confirm password:");

        txtAdminPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAdminPasswordActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlUpdateDetailsLayout = new javax.swing.GroupLayout(pnlUpdateDetails);
        pnlUpdateDetails.setLayout(pnlUpdateDetailsLayout);
        pnlUpdateDetailsLayout.setHorizontalGroup(
            pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlUpdateDetailsLayout.createSequentialGroup()
                .addGap(0, 176, Short.MAX_VALUE)
                .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                        .addComponent(lblAdminPassword)
                        .addGap(18, 18, 18)
                        .addComponent(txtAdminPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblAdminPasswordValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                        .addComponent(lblAdminUsername)
                        .addGap(25, 25, 25)
                        .addComponent(txtAdminUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblAdminUsernameValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnlUpdateDetailsLayout.createSequentialGroup()
                        .addComponent(lblAdminConfirmPassword)
                        .addGap(18, 18, 18)
                        .addComponent(txtAdminConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblAdminConfirmPasswordValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(105, 105, 105))
            .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(btnBack1))
                    .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                        .addGap(313, 313, 313)
                        .addComponent(btnUpdate))
                    .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                        .addGap(255, 255, 255)
                        .addComponent(lblUpdateDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlUpdateDetailsLayout.setVerticalGroup(
            pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlUpdateDetailsLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(btnBack1)
                .addGap(45, 45, 45)
                .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAdminUsernameValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtAdminUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblAdminUsername)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtAdminPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblAdminPassword))
                    .addComponent(lblAdminPasswordValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlUpdateDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtAdminConfirmPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblAdminConfirmPassword))
                    .addComponent(lblAdminConfirmPasswordValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addComponent(btnUpdate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblUpdateDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58))
        );

        getContentPane().add(pnlUpdateDetails);
        pnlUpdateDetails.setBounds(0, 0, 870, 470);

        btnBack2.setText("Back");
        btnBack2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBack2ActionPerformed(evt);
            }
        });

        txtHelp.setColumns(20);
        txtHelp.setRows(5);
        txtHelp.setText("To add more nurses to your clinic's database, select \"Add Nurse\" and enter\nthe chosen username and password.\n\nTo change the administrative login details, select \"Update Details\" and \nenter a new username and/or password.\n\nTo return to the login screen, select \"Log out.\"");
        jScrollPane1.setViewportView(txtHelp);

        javax.swing.GroupLayout pnlHelpLayout = new javax.swing.GroupLayout(pnlHelp);
        pnlHelp.setLayout(pnlHelpLayout);
        pnlHelpLayout.setHorizontalGroup(
            pnlHelpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHelpLayout.createSequentialGroup()
                .addGroup(pnlHelpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlHelpLayout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(btnBack2))
                    .addGroup(pnlHelpLayout.createSequentialGroup()
                        .addGap(138, 138, 138)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 598, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(134, Short.MAX_VALUE))
        );
        pnlHelpLayout.setVerticalGroup(
            pnlHelpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHelpLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(btnBack2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(103, Short.MAX_VALUE))
        );

        getContentPane().add(pnlHelp);
        pnlHelp.setBounds(0, 0, 870, 470);

        btnAddNurse.setText("Add Nurse");
        btnAddNurse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddNurseActionPerformed(evt);
            }
        });

        btnLogOut.setText("Log Out");
        btnLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogOutActionPerformed(evt);
            }
        });

        btnUpdateDetails.setText("Update Details");
        btnUpdateDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateDetailsActionPerformed(evt);
            }
        });

        btnHelp.setText("Help");
        btnHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHelpActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlAdminMenuLayout = new javax.swing.GroupLayout(pnlAdminMenu);
        pnlAdminMenu.setLayout(pnlAdminMenuLayout);
        pnlAdminMenuLayout.setHorizontalGroup(
            pnlAdminMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAdminMenuLayout.createSequentialGroup()
                .addGroup(pnlAdminMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlAdminMenuLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnLogOut))
                    .addGroup(pnlAdminMenuLayout.createSequentialGroup()
                        .addGap(366, 366, 366)
                        .addGroup(pnlAdminMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnAddNurse, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnUpdateDetails, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                            .addComponent(btnHelp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 496, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pnlAdminMenuLayout.setVerticalGroup(
            pnlAdminMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlAdminMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnLogOut)
                .addGap(121, 121, 121)
                .addComponent(btnAddNurse)
                .addGap(40, 40, 40)
                .addComponent(btnUpdateDetails)
                .addGap(41, 41, 41)
                .addComponent(btnHelp)
                .addContainerGap(295, Short.MAX_VALUE))
        );

        getContentPane().add(pnlAdminMenu);
        pnlAdminMenu.setBounds(0, 0, 1000, 600);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogOutActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new PAT2019UI().setVisible(true);
            }
        });
        
        this.dispose();
    }//GEN-LAST:event_btnLogOutActionPerformed

    private void btnAddNurseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddNurseActionPerformed
        pnlAdminMenu.setVisible(false);
        pnlAddNurse.setVisible(true);
    }//GEN-LAST:event_btnAddNurseActionPerformed

    private void btnUpdateDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateDetailsActionPerformed
        pnlAdminMenu.setVisible(false);
        pnlUpdateDetails.setVisible(true);
    }//GEN-LAST:event_btnUpdateDetailsActionPerformed

    private void btnHelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHelpActionPerformed
        pnlAdminMenu.setVisible(false);
        pnlHelp.setVisible(true);
    }//GEN-LAST:event_btnHelpActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        pnlAdminMenu.setVisible(true);
        pnlAddNurse.setVisible(false);
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnBack1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBack1ActionPerformed
        pnlAdminMenu.setVisible(true);
        pnlUpdateDetails.setVisible(false);
    }//GEN-LAST:event_btnBack1ActionPerformed

    private void btnBack2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBack2ActionPerformed
        pnlAdminMenu.setVisible(true);
        pnlHelp.setVisible(false);
    }//GEN-LAST:event_btnBack2ActionPerformed

    private void txtSetUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSetUsernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSetUsernameActionPerformed

    private void txtSetPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSetPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSetPasswordActionPerformed

    private void btnAddNurse1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddNurse1ActionPerformed
        lblUsernameValidation.setText("");
        lblPasswordValidation.setText("");
        lblConfirmPasswordValidation.setText("");
        lblNurseAdded.setText("");
        
        boolean user, pass1, pass2;
        
        user = false;
        pass1 = false;
        pass2 = false;
        
        username = txtSetUsername.getText();
        String p1, p2;
        p1 = String.valueOf(txtSetPassword.getPassword());
        p2 = String.valueOf(txtConfirmPassword.getPassword());
        
        ResultSet allUsernames;
        
        Connection connection = null;
        Statement statement = null;
    
        String msAccDB = "dbWCBS.accdb";
        String dbURL = "jdbc:ucanaccess://" + msAccDB; 
        
        
        
        if(txtSetUsername.getText().equalsIgnoreCase(""))
        {
            lblUsernameValidation.setText("Please enter a username.");
        }
        else
        {
            if(toArr.usernameInNurses(txtSetUsername.getText()))
            {
                lblUsernameValidation.setText("Username taken.");
            }
            else
            {
                user = true;
            }             
        }
        
        if(p1.equalsIgnoreCase(""))
        {
            lblPasswordValidation.setText("Please enter a password.");
        }
        else
        {
            pass1 = true;
        }
        
        if(p2.equalsIgnoreCase(""))
        {
            lblConfirmPasswordValidation.setText("Please confirm password.");
        }
        else 
        {
            if(p2.equals(p1))
            {
                pass2 = true;
            }
            else
            {
                lblConfirmPasswordValidation.setText("Passwords do not match.");
            }
        }
        
        if(user && pass1 && pass2)
        {
            Nurse nurse = new Nurse(username, p1);
            
            nurse.toTable();
            
            lblNurseAdded.setText("Nurse added.");
        }
    }//GEN-LAST:event_btnAddNurse1ActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        lblAdminUsernameValidation.setText("");
        lblAdminConfirmPasswordValidation.setText("");
        lblAdminPasswordValidation.setText("");
        lblUpdateDetails.setText("");
        
        Admin admin = toArr.getAdmin();
        
        boolean user, pass1, pass2;
        
        user = false;
        pass1 = false;
        pass2 = false;
        
        username = txtAdminUsername.getText();
        String p1, p2;
        p1 = String.valueOf(txtAdminPassword.getPassword());
        p2 = String.valueOf(txtAdminConfirmPassword.getPassword());
                       
        Connection connection = null;
        Statement statement = null;
    
        String msAccDB = "dbWCBS.accdb";
        String dbURL = "jdbc:ucanaccess://" + msAccDB; 
                       
        if(txtAdminUsername.getText().equalsIgnoreCase(""))
        {
            lblAdminUsernameValidation.setText("Please enter a username.");
        }
        else
        {
            user = true;           
        }
        
        if(p1.equalsIgnoreCase(""))
        {
            lblAdminPasswordValidation.setText("Please enter a password.");
        }
        else
        {
            pass1 = true;
        }
        
        if(p2.equalsIgnoreCase(""))
        {
            lblAdminConfirmPasswordValidation.setText("Please confirm password.");
        }
        else 
        {
            if(p2.equals(p1))
            {
                pass2 = true;
            }
            else
            {
                lblAdminConfirmPasswordValidation.setText("Passwords do not match.");
            }
        }
        
        if(user && pass1 && pass2)
        {
           lblUpdateDetails.setText("Username and password updated.");
           admin.setPassword(p1);
           admin.setUsername(username);          
        }
        else if(user && (!pass1 || !pass2))
        {
            lblUpdateDetails.setText("Username updated.");
            admin.setUsername(username);  
        }
        else if(pass1 && pass2 && !user)
        {
            lblUpdateDetails.setText("Password updated.");
            admin.setPassword(p1);
        }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void txtAdminUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAdminUsernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAdminUsernameActionPerformed

    private void txtAdminPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAdminPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAdminPasswordActionPerformed

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddNurse;
    private javax.swing.JButton btnAddNurse1;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnBack1;
    private javax.swing.JButton btnBack2;
    private javax.swing.JButton btnHelp;
    private javax.swing.JButton btnLogOut;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btnUpdateDetails;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblAdminConfirmPassword;
    private javax.swing.JLabel lblAdminConfirmPasswordValidation;
    private javax.swing.JLabel lblAdminPassword;
    private javax.swing.JLabel lblAdminPasswordValidation;
    private javax.swing.JLabel lblAdminUsername;
    private javax.swing.JLabel lblAdminUsernameValidation;
    private javax.swing.JLabel lblConfirmPassword;
    private javax.swing.JLabel lblConfirmPasswordValidation;
    private javax.swing.JLabel lblNurseAdded;
    private javax.swing.JLabel lblPasswordValidation;
    private javax.swing.JLabel lblSetPassword;
    private javax.swing.JLabel lblSetUsername;
    private javax.swing.JLabel lblUpdateDetails;
    private javax.swing.JLabel lblUsernameValidation;
    private javax.swing.JPanel pnlAddNurse;
    private javax.swing.JPanel pnlAdminMenu;
    private javax.swing.JPanel pnlHelp;
    private javax.swing.JPanel pnlUpdateDetails;
    private javax.swing.JPasswordField txtAdminConfirmPassword;
    private javax.swing.JPasswordField txtAdminPassword;
    private javax.swing.JTextField txtAdminUsername;
    private javax.swing.JPasswordField txtConfirmPassword;
    private javax.swing.JTextArea txtHelp;
    private javax.swing.JPasswordField txtSetPassword;
    private javax.swing.JTextField txtSetUsername;
    // End of variables declaration//GEN-END:variables
}
