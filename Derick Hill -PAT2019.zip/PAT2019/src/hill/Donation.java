package hill;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Donation 
{
    private Date donationDate;
    private PreparedStatement donation;
    
    private Connection connection = null;
    private Statement statement = null;
    
    private final String msAccDB = "dbWCBS.accdb";
    private final String dbURL = "jdbc:ucanaccess://" + msAccDB; 
    
    Donation(Date a)//Instantiates a Donation object with the accepted date as the donation date.
    {
        donationDate = a;
    }
    
    public Date getDonationDate()//Returns the donation date.
    {
        return donationDate;
    }
    
    public void toTable(int id)//Inserts the object’s value as a new record in tblDonation where the QuestionnaireID field equals the accepted integer.
    {
        String sqlStatement;
        
        try 
        {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        }
        catch(ClassNotFoundException cnfex) 
        {
 
            System.out.println("Problem in loading or registering MS Access JDBC driver");
            cnfex.printStackTrace();
        }
        try 
        {
           SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
           final String stringDate= dateFormat.format(Calendar.getInstance().getTime());
            
            
           connection = DriverManager.getConnection(dbURL); 

           statement = connection.createStatement();
                                
           sqlStatement = "INSERT INTO tblDonations(QuestionnaireID, [Donation Date])"
                            + " VALUES( " + id + " , #" + stringDate + "# )";
            
           donation = connection.prepareStatement(sqlStatement);
           donation.executeUpdate();
        }
        catch(SQLException sqlex)
        {
            sqlex.printStackTrace();
        }
    }
}
