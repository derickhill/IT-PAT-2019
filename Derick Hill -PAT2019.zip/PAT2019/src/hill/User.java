package hill;

public class User 
{
    String username;
    String password;
    
    User(String a, String b) //Used to instantiate a User object, using the two strings as username and password.
    {
        username = a;
        password = b;
    }
}
