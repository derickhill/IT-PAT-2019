package hill;
        
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Admin extends User
{
    private PreparedStatement admin;
    
    private Connection connection = null;
    private Statement statement = null;
    
    private final String msAccDB = "dbWCBS.accdb";
    private final String dbURL = "jdbc:ucanaccess://" + msAccDB; 
    
    Admin(String a, String b)//Instantiates an Admin object using the accepted strings as username and password.
    {
        super(a,b);
    }
            
    public void setUsername(String user)//Sets the username to the value of the accepted string and updates this value in tblAdmin.
    {
        String sqlStatement = "UPDATE tblAdmin SET Username = \"" + user + "\" WHERE AdminID = 1";
        
        try 
        {
            connection = DriverManager.getConnection(dbURL); 

            statement = connection.createStatement();
            
            admin = connection.prepareStatement(sqlStatement);
            admin.executeUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Donor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        username = user;
    }
    
    public void setPassword(String pass)//Sets the password to the value of the accepted string and updates this value in tblAdmin.
    {
        String sqlStatement = "UPDATE tblAdmin SET Password = \"" + pass + "\" WHERE AdminID = 1";
        
        try 
        {
            connection = DriverManager.getConnection(dbURL); 

            statement = connection.createStatement();
            
            admin = connection.prepareStatement(sqlStatement);
            admin.executeUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Donor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        password = pass;
    }
}